#include "Object.cpp"
#include <string>

#define MAIN_PAGE (Current_Page == &MainPage)
#define MAP_PAGE (Current_Page == &MapPage)
#define OBJECT_PAGE (Current_Page == &ObjectPage)
#define MOVEMENT_PAGE (Current_Page == &MovementPage)
#define EXIT_PAGE (Current_Page == &ExitPage)

GLsizei WIDTH = 1300, HEIGHT = 1000; // Describes Screen Size
const char* strP;

char strxp[4] = { 'X','+','\0' };
char strxm[4] = { 'X','-','\0' };
char stryp[4] = { 'Y','+','\0' };
char strym[4] = { 'Y','-','\0' };
char strzp[4] = { 'Z','+','\0' };
char strzm[4] = { 'Z','-','\0' };
float Rx = 0, Ry = 0, Rz = 0;
float distance_C = -5;
int MouseY = 0, MouseX = 0;
int Exit_Flag = 0;
int RotateFlag = 0, Rotateing = 0;
int Showing = 0;
int Hideing = 0;
int Typeing = 0;
int Working = 0;
int SettingMove = 0;
int MoveingIdle = 0;
int List = 0;
int Option_List = 0;
int Options_Count = 0;
float Option_Y;
int HideRestNum = 0;
Button BuildObject;
Button BuildMap;
Button ExitButton;

Button SavePlans;
Button HideRest;
Button RotateLeft;
Button RotateRight;
Button SaveObject;
Button LoadObject;
Button TypeObject;
Button HideShowAxis;
Button Convert;
Button YES;
Button NO;
Button SaveMap;
Button LoadMap;
Button RotateBuild;

Button SetMove;
Button MoveIdle;
Button AblyMove;
Button BackMove;
Button LFX, LTX, LFY, LTY, LFZ, LTZ, LS;
Button RFX, RTX, RFY, RTY, RFZ, RTZ, RS;
Button SFX, STX, SFY, STY, SFZ, STZ, SS;
Button CFX, CTX, CFY, CTY, CFZ, CTZ, CS;
Button* TypeBtn;

Object Ob1,Ob2;
Object object;
Object Building[100];
Button OBBtn0, OBBtn1, OBBtn2;
Button BuildingBtn[100];
Button Buildings_Option[200];
Button NextList;
Button ReqMove;
Button NextOptionList;
Object Stations[3];
Object Level_Build[2];

Box* Working_Box;

Page* Current_Page;

Page MainPage;
Page MapPage;
Page ObjectPage;
Page MovementPage;
Page ExitPage;



D_Vertex* Working_Vertex = NULL;

char PlansIn[3][10];
int Plans[3][3][10][3];

char PlanIndex, Plan, Difficult;
bool ReqMoveFlag = false;
int i, ObMove;
char strData[80];
char buff[15];
int VertexOption;
int ForAdd = 10;
int Mode = 0;
int CameraX, CameraY, CameraZ;
int polymore = 0;

void Type_Name(char* str, char ch)
{
	if (strlen(str) > 10)return;
	int i = 0;
	while (*(str + i) != 0)
		i++;
	*(str + (i++)) = ch;
	*(str + i) = 0;
}
void Remove_Char(char* str)
{
	int i = 0;
	if (str == "")return;
	*(str + (strlen(str) - 1)) = 0;
}
const char* VertexToString(D_Vertex* v)
{
	if (v == NULL)
		return "-            -            -";
	strcpy(strData, "");
	gcvt(v->x, 6, buff);
	strcat(strData, buff);
	strcat(strData, "           ");
	gcvt(v->y, 6, buff);
	strcat(strData, buff);
	strcat(strData, "           ");
	gcvt(v->z, 6, buff);
	strcat(strData, buff);
	return strData;
}

void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, (GLfloat)w / (GLfloat)h, 1.0, 300);
	glMatrixMode(GL_MODELVIEW);
	WIDTH = w;
	HEIGHT = h;
}

void PrintStringAt(float x, float y, float z, float r, float g, float b, const char* str)
{
	strP = str;
	glColor3f(r, g, b);
	glRasterPos3f(x, y, z);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));
}

void MoveDone()
{
	Box* B = &object.box[object.BoxIndex];
	float x, y, z;
	B->ReqMove = ReqMoveFlag;
	if (LS.str[0] != 'N') {
		B->Moving_Location = 1;
		sscanf(LFX.str, "%f", &x);
		sscanf(LFY.str, "%f", &y);
		sscanf(LFZ.str, "%f", &z);
		B->LocationFrom.Set_(x, y, z);
		sscanf(LTX.str, "%f", &x);
		sscanf(LTY.str, "%f", &y);
		sscanf(LTZ.str, "%f", &z);
		B->LocationTo.Set_(x, y, z);
		sscanf(LS.str, "%f %f %f", &x, &y, &z);
		B->LocationSpeed.Set_(x, y, z);
	}
	if (RS.str[0] != 'N') {
		B->Moving_Rotation = 1;
		sscanf(RFX.str, "%f", &x);
		sscanf(RFY.str, "%f", &y);
		sscanf(RFZ.str, "%f", &z);
		B->RotationFrom.Set_(x, y, z);
		sscanf(RTX.str, "%f", &x);
		sscanf(RTY.str, "%f", &y);
		sscanf(RTZ.str, "%f", &z);
		B->RotationTo.Set_(x, y, z);
		sscanf(RS.str, "%f %f %f", &x, &y, &z);
		B->RotationSpeed.Set_(x, y, z);
	}
	if (SS.str[0] != 'N') {
		B->Moving_Size = 1;
		sscanf(SFX.str, "%f", &x);
		sscanf(SFY.str, "%f", &y);
		sscanf(SFZ.str, "%f", &z);
		B->SizeFrom.Set_(x, y, z);
		sscanf(STX.str, "%f", &x);
		sscanf(STY.str, "%f", &y);
		sscanf(STZ.str, "%f", &z);
		B->SizeTo.Set_(x, y, z);
		sscanf(SS.str, "%f %f %f", &x, &y, &z);
		B->SizeSpeed.Set_(x, y, z);
	}
	if (CS.str[0] != 'N') {
		B->Moving_Color = 1;
		sscanf(CFX.str, "%f", &x);
		sscanf(CFY.str, "%f", &y);
		sscanf(CFZ.str, "%f", &z);
		B->ColorFrom.Set_(x, y, z);
		sscanf(CTX.str, "%f", &x);
		sscanf(CTY.str, "%f", &y);
		sscanf(CTZ.str, "%f", &z);
		B->ColorTo.Set_(x, y, z);
		sscanf(CS.str, "%f %f %f", &x, &y, &z);
		B->ColorSpeed.Set_(x, y, z);
	}
}
void SaveMapFunc()
{
	ofstream myfile;
	string FileName(TypeObject.str);
	FileName += ".txt";
	myfile.open(FileName);

	for (i = 0; i < 100; i++)
	{
		if (Building[i].Box_Count != 0)
		{
			myfile << Building[i].Box_Count << " " << Building[i].Location.x;
			myfile << " " << Building[i].Location.y;
			myfile << " " << Building[i].Location.z << "  " << Building[i].ObjName << endl;
		}
	}
	myfile.close();
}
void passiveMotionFunc(int x, int y)
{
	if (Showing)
	{
		for (i = 0; i < 100; i++)
		{
			if (BuildingBtn[i].Color.y == 0)
			{
				if (MouseX < x)Building[i].Location.x += 0.5;
				if (MouseX > x)Building[i].Location.x -= 0.5;
				if (MouseY < y)Building[i].Location.z += 0.5;
				if (MouseY > y)Building[i].Location.z -= 0.5;
				break;
			}
		}
		if (i == 100)
		{
			if (MouseX < x)Ry += 1;
			if (MouseX > x)Ry -= 1;
			if (MouseY < y)Rx += 1;
			if (MouseY > y)Rx -= 1;
		}

		MouseX = x;
		MouseY = y;
	}
}
void glutMouseClick(int btn, int state, int x, int y)
{
	if (btn == 2)
	{
		for (i = 0; i < 100; i++)
			BuildingBtn[i].Color.Set_(1, 1, 1);
		return;
	}
	if (state != GLUT_DOWN)return;
	Typeing = 0;
	TypeObject.Color.Set_(1, 1, 1);
	if (MAIN_PAGE)
	{
		if (BuildMap.Clicked(x, y)) {
			Current_Page = &MapPage;
			return;
		}
		if (BuildObject.Clicked(x, y)) {
			TypeObject.init(-4.5, -2.0, 0.5, 1, 1, 1, "");
			Current_Page = &ObjectPage;
			return;
		}
		if (LoadMap.Clicked(x, y))
		{
			ifstream input_file;
			string BuildName;
			float x, y, z, d;
			input_file.open(TypeObject.str, std::ios_base::app);
			i = 0;
			while (getline(input_file, BuildName)) {
				stringstream data(BuildName);
				data >> d >> x >> y >> z >> BuildName;
				Building[i].Load_Project(BuildName);
				Building[i++].Location.Set_(x, y, z);
			}
			input_file.close();
		}
		if (SaveMap.Clicked(x, y)) {
			SaveMapFunc();
		}
		if (ExitButton.Clicked(x, y))
		{
			Current_Page = &ExitPage;
			return;
		}
		if (TypeObject.Clicked(x, y)) {
			Typeing = 1;
			TypeBtn->Color.Set_(0, 0, 0);
			TypeBtn = &TypeObject;
			TypeBtn->Color.Set_(1, 0, 0);
			return;
		}
		if (SavePlans.Clicked(x, y))
		{
			if (strcmp(TypeObject.str, "") == 0)
			{
				return;
			}
			string FileEasyDefend = TypeObject.str;
			string FileEasyMid = TypeObject.str;
			string FileEasyAttack = TypeObject.str;
			string FileMidDefend = TypeObject.str;
			string FileMidMid = TypeObject.str;
			string FileMidAttack = TypeObject.str;
			string FileHardDefend = TypeObject.str;
			string FileHardMid = TypeObject.str;
			string FileHardAttack = TypeObject.str;
			FileEasyDefend += "_EasyDefendPlan.txt";
			FileEasyMid += "_EasyMidPlan.txt";
			FileEasyAttack += "_EasyAttackPlan.txt";
			FileMidDefend += "_MidDefendPlan.txt";
			FileMidMid += "_MidMidPlan.txt";
			FileMidAttack += "_MidAttackPlan.txt";
			FileHardDefend += "_HardDefendPlan.txt";
			FileHardMid += "_HardMidPlan.txt";
			FileHardAttack += "_HardAttackPlan.txt";
			ofstream myfile;
			{
				myfile.open(FileEasyDefend);
				for (int i = 0; i < 10; i++)
					myfile << Plans[0][0][i][0] << " " << Plans[0][0][i][1] << " " << Plans[0][0][i][2] << endl;
				myfile.close();
				myfile.open(FileEasyMid);
				for (int i = 0; i < 10; i++)
					myfile << Plans[0][1][i][0] << " " << Plans[0][1][i][1] << " " << Plans[0][1][i][2] << endl;
				myfile.close();
				myfile.open(FileEasyAttack);
				for (int i = 0; i < 10; i++)
					myfile << Plans[0][2][i][0] << " " << Plans[0][2][i][1] << " " << Plans[0][2][i][2] << endl;
				myfile.close();
			}
			{
				myfile.open(FileMidDefend);
				for (int i = 0; i < 10; i++)
					myfile << Plans[1][0][i][0] << " " << Plans[1][0][i][1] << " " << Plans[1][0][i][2] << endl;
				myfile.close();
				myfile.open(FileMidMid);
				for (int i = 0; i < 10; i++)
					myfile << Plans[1][1][i][0] << " " << Plans[1][1][i][1] << " " << Plans[1][1][i][2] << endl;
				myfile.close();
				myfile.open(FileMidAttack);
				for (int i = 0; i < 10; i++)
					myfile << Plans[1][2][i][0] << " " << Plans[1][2][i][1] << " " << Plans[1][2][i][2] << endl;
				myfile.close();
			}
			{
				myfile.open(FileHardDefend);
				for (int i = 0; i < 10; i++)
					myfile << Plans[2][0][i][0] << " " << Plans[2][0][i][1] << " " << Plans[2][0][i][2] << endl;
				myfile.close();
				myfile.open(FileHardMid);
				for (int i = 0; i < 10; i++)
					myfile << Plans[2][1][i][0] << " " << Plans[2][1][i][1] << " " << Plans[2][1][i][2] << endl;
				myfile.close();
				myfile.open(FileHardAttack);
				for (int i = 0; i < 10; i++)
					myfile << Plans[2][2][i][0] << " " << Plans[2][2][i][1] << " " << Plans[2][2][i][2] << endl;
				myfile.close();
			}
		}
	}
	if (MAP_PAGE)
	{
		if (NextList.Clicked(x, y)) {
			List = (List + 1) % 10;
		}
		if (NextOptionList.Clicked(x, y)) {
			Option_List = (Option_List + 1) % ((Options_Count / 8) + (Options_Count % 8 > 0));
		}
		for (int i = 0; i < 200; i++)
		{
			if (i >= Option_List * 8 && i < (Option_List * 8) + 8)
				if (Buildings_Option[i].Clicked(x, y)) {
					for (int j = 0; j < 100; j++)
					{
						if (BuildingBtn[j].Color.y == 0) {
							Building[j].Load_Project(Buildings_Option[i].str);
							Building[j].Location.Set_(-CameraX, -CameraY, -CameraZ);
							if (polymore)
							{
								Building[j + 50].Load_Project(Buildings_Option[i].str);
								Building[j + 50].Location.Set_(60 + CameraX - 2, -CameraY, 100 + CameraZ - 2);
							}
						}
					}
					TypeBtn->Color.Set_(1, 1, 1);
				}
		}
		for (i = 0; i < 10; i++)
		{
			if (BuildingBtn[i + List * 10].Clicked(x, y)) {
				TypeBtn->Color.Set_(1, 1, 1);
				BuildingBtn[i + List * 10].Color.Set_(1, 0, 0);
				TypeBtn = &BuildingBtn[i + List * 10];
				return;
			}
		}
		if (i == 20 && x < 180 || x>1400 || y < 150 || y>720)
		{
			for (i = 0; i < 100; i++)
				BuildingBtn[i].Color.Set_(1, 1, 1);
		}
		if (!(x < 180 || x>1400 || y < 150 || y>720))
			Showing = !Showing;
	}
	if (OBJECT_PAGE)
	{
		if (SetMove.Clicked(x, y) )
		{
			Current_Page = &MovementPage;
			return;
		}
		if (HideShowAxis.Clicked(x, y) ) { 
			Hideing = !Hideing;
			return; 
		};
		if (RotateRight.Clicked(x, y) ) { 
			RotateFlag += 1;
			return; 
		}
		if (RotateLeft.Clicked(x, y) ) { 
			RotateFlag += -1; 
			return; 
		}
		if (LoadObject.Clicked(x, y) ) { 
			object.Load_Project(TypeObject.str); 
			return; 
		}
		if (OBBtn0.Clicked(x, y))  { 
			ObMove = 0;
			return; 
		}
		if (OBBtn1.Clicked(x, y) ) {
			ObMove = 1;
			Ob1.Load_Project(TypeObject.str); return; 
		}
		if (OBBtn2.Clicked(x, y) ) {
			ObMove = 2; 
			Ob2.Load_Project(TypeObject.str); return;
		}
		if (SaveObject.Clicked(x, y) ) {
			if (RotateBuild.Color.y == 1)
			{
				std::ofstream outfile;
				outfile.open("Buildings.txt", std::ios_base::app);
				object.Save_Project(TypeObject.str);
				outfile << TypeObject.str << "\n";
				outfile.close();
			}
			else
			{
				std::ofstream outfile;
				outfile.open("Buildings.txt", std::ios_base::app);
				char BuildName[20];
				strcpy(BuildName, TypeObject.str);
				strcat(BuildName, "F");
				object.Save_Project(BuildName);
				outfile << BuildName << "\n";
				strcpy(BuildName, TypeObject.str);
				strcat(BuildName, "B");
				object.RotateBack();
				object.Save_Project(BuildName);
				outfile << BuildName << "\n";
				strcpy(BuildName, TypeObject.str);
				strcat(BuildName, "R");
				object.RotateBack();
				object.RotateRight();
				object.Save_Project(BuildName);
				outfile << BuildName << "\n";
				strcpy(BuildName, TypeObject.str);
				strcat(BuildName, "L");
				object.RotateRight();
				object.RotateLeft();
				object.Save_Project(BuildName);
				outfile << BuildName << "\n";
				outfile.close();
			}
			Options_Count = 0;
			Option_Y = 2.5;
			string filename("Buildings.txt");
			ifstream input_file(filename);
			while (getline(input_file, filename)) {
				Buildings_Option[Options_Count].init(4.7, Option_Y, 0.5, 1, 1, 1, "");
				strcpy(Buildings_Option[Options_Count++].str, filename.c_str());
				Option_Y -= 0.5;
				if (Option_Y < -1.0)Option_Y = 2.5;
			}
			input_file.close();

			return;
		}
		if (RotateBuild.Clicked(x, y)) {
			if (RotateBuild.Color.y == 1) {
				RotateBuild.Color.Set_(1, 0, 0);
				strcpy(RotateBuild.str, "Rotate : On");
			}
			else {
				RotateBuild.Color.Set_(1, 1, 1);
				strcpy(RotateBuild.str, "Rotate : Off");
			}
			return;
		}
		if (HideRest.Clicked(x, y)) {
			HideRestNum = !HideRestNum;
			return;
		}


		if (Convert.Clicked(x, y)) { 
			object.Build(TypeObject.str);
			return;
		}
		if (TypeObject.Clicked(x, y)) {
			Typeing = 1;
			TypeBtn->Color.Set_(0, 0, 0);
			TypeBtn = &TypeObject;
			TypeBtn->Color.Set_(1, 0, 0);
			return;
		}
		if (MoveIdle.Clicked(x, y))
		{
			MoveingIdle = !MoveingIdle;
			return;
		}

		if (AblyMove.Clicked(x, y))
		{
			MoveDone();
			SettingMove = 0;
			return;
		}
		if (!(x < 180 || x>1400 || y < 150 || y>720))
			Showing = !Showing;
	}
	if (MOVEMENT_PAGE)
	{
		Typeing = 0;
		TypeBtn->Color.Set_(0, 0, 0);
		if (LFX.Clicked(x, y)) { TypeBtn = &LFX; Typeing = 1; }
		if (LTX.Clicked(x, y)) { TypeBtn = &LTX; Typeing = 1; }
		if (LFY.Clicked(x, y)) { TypeBtn = &LFY; Typeing = 1; }
		if (LTY.Clicked(x, y)) { TypeBtn = &LTY; Typeing = 1; }
		if (LFZ.Clicked(x, y)) { TypeBtn = &LFZ; Typeing = 1; }
		if (LTZ.Clicked(x, y)) { TypeBtn = &LTZ; Typeing = 1; }
		if (LS.Clicked(x, y)) { TypeBtn = &LS; Typeing = 1; }

		if (RFX.Clicked(x, y)) { TypeBtn = &RFX; Typeing = 1; }
		if (RTX.Clicked(x, y)) { TypeBtn = &RTX; Typeing = 1; }
		if (RFY.Clicked(x, y)) { TypeBtn = &RFY; Typeing = 1; }
		if (RTY.Clicked(x, y)) { TypeBtn = &RTY; Typeing = 1; }
		if (RFZ.Clicked(x, y)) { TypeBtn = &RFZ; Typeing = 1; }
		if (RTZ.Clicked(x, y)) { TypeBtn = &RTZ; Typeing = 1; }
		if (RS.Clicked(x, y)) { TypeBtn = &RS; Typeing = 1; }

		if (SFX.Clicked(x, y)) { TypeBtn = &SFX; Typeing = 1; }
		if (STX.Clicked(x, y)) { TypeBtn = &STX; Typeing = 1; }
		if (SFY.Clicked(x, y)) { TypeBtn = &SFY; Typeing = 1; }
		if (STY.Clicked(x, y)) { TypeBtn = &STY; Typeing = 1; }
		if (SFZ.Clicked(x, y)) { TypeBtn = &SFZ; Typeing = 1; }
		if (STZ.Clicked(x, y)) { TypeBtn = &STZ; Typeing = 1; }
		if (SS.Clicked(x, y)) { TypeBtn = &SS; Typeing = 1; }

		if (CFX.Clicked(x, y)) { TypeBtn = &CFX; Typeing = 1; }
		if (CTX.Clicked(x, y)) { TypeBtn = &CTX; Typeing = 1; }
		if (CFY.Clicked(x, y)) { TypeBtn = &CFY; Typeing = 1; }
		if (CTY.Clicked(x, y)) { TypeBtn = &CTY; Typeing = 1; }
		if (CFZ.Clicked(x, y)) { TypeBtn = &CFZ; Typeing = 1; }
		if (CTZ.Clicked(x, y)) { TypeBtn = &CTZ; Typeing = 1; }
		if (CS.Clicked(x, y)) { TypeBtn = &CS; Typeing = 1; }
		if (ReqMove.Clicked(x, y))
		{
			ReqMoveFlag = !ReqMoveFlag;
			if (ReqMoveFlag)
				ReqMove.init(4.7, 1.0, 0.45, 10, 10, 0, "ReqMove:ON");
			else
				ReqMove.init(4.7, 1.0, 0.45, 10, 0, 0, "ReqMove:OFF");
			return;
		}
		if (BackMove.Clicked(x, y))
		{
			Current_Page = &ObjectPage;
			return;
		}
		if (Typeing)TypeBtn->Color.Set_(1, 0, 0);
	}
	if (EXIT_PAGE)
	{
		if (YES.Clicked(x, y))
		{
			exit(EXIT_SUCCESS);

		}
		if (NO.Clicked(x, y))
		{
			Current_Page = &MainPage;
			return;
		}
	}

	object.HideArrows = !Showing;



}
void keyboard(unsigned char key, int x, int y)
{
	if (Typeing)
	{
		if (key == 27 || key == 13) {
			Typeing = 0;
			TypeObject.Color.Set_(0, 0, 0);
			return;
		}
		if (key == 8)
			Remove_Char(TypeBtn->str);
		else
			Type_Name(TypeBtn->str, key);
		return;
	}
	if (key == 27)
	{
		if (EXIT_PAGE)exit(EXIT_SUCCESS);
		Current_Page = Current_Page->Back;
		if (Current_Page == &MainPage)
			TypeObject.init(0, 1.5, 0.5, 1, 1, 1, "");
		return;
	}
	if (MAIN_PAGE) {

	}	
	if (MOVEMENT_PAGE) {

	}
	if (OBJECT_PAGE) {
		if (key == 'u') {
			if (object.Box_Count < 30) {
				Working_Box = &object.box[object.Box_Count];
				object.Box_Count++;
				object.BoxIndex = object.Box_Count - 1;
			}
		}
		if (key == 'U')
		{
			if (object.Box_Count > 1) {
				object.Box_Count--;
				Working_Box = &object.box[object.Box_Count];
				object.BoxIndex = object.Box_Count - 1;
			}
		}

		if (key == 'q')VertexOption = 1;
		if (key == 'w')VertexOption = 2;
		if (key == 'e')VertexOption = 3;
		if (key == 'r')VertexOption = 4;
		if (key == ']')
		{
			if (object.BoxIndex < object.Box_Count - 1)
			{
				object.BoxIndex++;
				Working_Box = &object.box[object.BoxIndex];
			}
		}
		if (key == '[' && object.BoxIndex > 0)
		{
			if (object.BoxIndex > 0)
			{
				object.BoxIndex--;
				Working_Box = &object.box[object.BoxIndex];
			}
		}
		if (key == 'o') { object.SaveBox(); }
		if (key == 'p') { object.CopyBox(); }
		if (key == '0') { ObMove = 0; return; }
		switch (ObMove)
		{
			case 0:
				if (key == 'A')object.Location.x-= (1 / (float)ForAdd);
				if (key == 'D')object.Location.x+= (1 / (float)ForAdd);
				if (key == 'W')object.Location.z-= (1 / (float)ForAdd);
				if (key == 'S')object.Location.z+= (1 / (float)ForAdd);
				if (key == 'Q')object.Location.y -= (1 / (float)ForAdd);
				if (key == 'E')object.Location.y += (1 / (float)ForAdd);
				break;
			case 1:
				if (key == 'A')Ob1.Location.x-= (1 / (float)ForAdd);
				if (key == 'D')Ob1.Location.x+= (1 / (float)ForAdd);
				if (key == 'W')Ob1.Location.z-= (1 / (float)ForAdd);
				if (key == 'S')Ob1.Location.z+= (1 / (float)ForAdd);
				if (key == 'Q')Ob1.Location.y-= (1 / (float)ForAdd);
				if (key == 'E')Ob1.Location.y+= (1 / (float)ForAdd);
				if (key == 'K')Ob1.Rotation.y --;
				if (key == 'L')Ob1.Rotation.y ++;
				break;
			case 2:
				if (key == 'A')Ob2.Location.x-= (1 / (float)ForAdd);
				if (key == 'D')Ob2.Location.x+= (1 / (float)ForAdd);
				if (key == 'W')Ob2.Location.z-= (1 / (float)ForAdd);
				if (key == 'S')Ob2.Location.z+= (1 / (float)ForAdd);
				if (key == 'Q')Ob2.Location.y-= (1 / (float)ForAdd);
				if (key == 'E')Ob2.Location.y+= (1 / (float)ForAdd);
				if (key == 'K')Ob2.Rotation.y --;
				if (key == 'L')Ob2.Rotation.y ++;
			break;
		}
		switch (VertexOption)
		{
		case 1:
			Working_Vertex = &object.box[object.BoxIndex].Location;
			break;
		case 2:
			Working_Vertex = &object.box[object.BoxIndex].Rotation;
			break;
		case 3:
			Working_Vertex = &object.box[object.BoxIndex].Size;
			break;
		case 4:
			Working_Vertex = &object.box[object.BoxIndex].Color;
			break;
		}
		if (Working_Vertex != NULL) {
			if (key == '7')Working_Vertex->INC_X((1 / (float)ForAdd));
			if (key == '4')Working_Vertex->INC_X(-1 / (float)ForAdd);
			if (key == '8')Working_Vertex->INC_Y(1 / (float)ForAdd);
			if (key == '5')Working_Vertex->INC_Y(-1 / (float)ForAdd);
			if (key == '9')Working_Vertex->INC_Z(1 / (float)ForAdd);
			if (key == '6')Working_Vertex->INC_Z(-1 / (float)ForAdd);
		}
		if (key == 'x')object.box[object.BoxIndex].Nets_Count++;
		if (key == 'X' && object.box[object.BoxIndex].Nets_Count > 0)object.box[object.BoxIndex].Nets_Count--;
		if (key == 'z')ForAdd *= 10;
		if (key == 'Z' && ForAdd > 1)ForAdd /= 10;
		if (key == 'c')object.box[object.BoxIndex].PlusX += (1 / (float)ForAdd);
		if (key == 'C')object.box[object.BoxIndex].PlusX -= (1 / (float)ForAdd);
		if (key == 'v')object.box[object.BoxIndex].PlusZ += (1 / (float)ForAdd);
		if (key == 'V')object.box[object.BoxIndex].PlusZ -= (1 / (float)ForAdd);
	}
	if (MAP_PAGE)
	{
		if (key == '[')
		{
			if (PlanIndex > 0)
				PlanIndex--;
			return;
		}
		if (key == ']')
		{
			if (PlanIndex < 9)
				PlanIndex++;
			return;
		}
		if (key == '(')
		{
			if (Difficult > 0)
				Difficult--;
			return;
		}
		if (key == ')')
		{
			if (Difficult < 3)
				Difficult++;
			return;
		}
		if (key == '}')
		{
			if (Plan < 2)
				Plan++;
			return;
		}
		if (key == '{')
		{
			if (Plan > 0)
				Plan--;
			return;
		}
		if (key == 'Z' || key == 'X' || key == 'C' || key == 'V')
		{
			PlansIn[Plan][PlanIndex] = 1;
			Plans[Difficult][Plan][PlanIndex][0] = -CameraX;
			Plans[Difficult][Plan][PlanIndex][1] = -CameraZ;
			if (key == 'Z')Plans[Difficult][Plan][PlanIndex][2] = 1;
			if (key == 'X')Plans[Difficult][Plan][PlanIndex][2] = 2;
			if (key == 'C')Plans[Difficult][Plan][PlanIndex][2] = 3;
			if (key == 'V')Plans[Difficult][Plan][PlanIndex][2] = 4;
			if (PlanIndex < 9)
				PlanIndex++;
			return;
		}
		if (key == 'd')CameraX--;
		if (key == 'a')CameraX++;
		if (key == 's')CameraZ--;
		if (key == 'w')CameraZ++;
		if (key == 'e')CameraY--;
		if (key == 'q')CameraY++;
		if (key == '`')key = '0';
		if (key == 'B') polymore = !polymore;
		if (key >= '0' && key <= '9')
		{
			for (i = 0; i < 100; i++)
				BuildingBtn[i].Color.Set_(1, 1, 1);
			i = key - '0';
			i += (List) * 10;
			BuildingBtn[i].Color.Set_(1, 0, 0);
			return;
		}
	}
	
	if (key == '+')distance_C++;
	if (key == '-')distance_C--;

	glutPostRedisplay();
}
void Draw_Axis()
{

	glTranslatef(0, 0, distance_C);
	glRotatef(Rx, 1, 0, 0);
	glRotatef(Ry, 0, 1, 0);
	glRotatef(Rz, 0, 0, 1);

	if (Hideing)return;
	strP = strzm;
	glColor3f(1, 0, 0);
	glRasterPos3f(0, 0, -5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	strP = strzp;
	glColor3f(1, 0, 0);
	glRasterPos3f(0, 0, 5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	glColor3f(0, 1, 0);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 10);    // First endpoint of line
	glVertex3f(0, 0, -10);    // Second endpoint of line
	glEnd();

	strP = stryp;
	glColor3f(0, 0, 1);
	glRasterPos3f(0, 5, 0);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	strP = strym;
	glColor3f(0, 0, 1);
	glRasterPos3f(0, -5, 0);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	glColor3f(0, 0, 1);
	glBegin(GL_LINES);
	glVertex3f(0, 10, 0);    // First endpoint of line
	glVertex3f(0, -10, 0);    // Second endpoint of line
	glEnd();


	strP = strxp;
	glColor3f(1, 1, 0);
	glRasterPos3f(5, 0, 0);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	strP = strxm;
	glColor3f(1, 1, 0);
	glRasterPos3f(-5, 0, 0);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));

	glColor3f(1, 1, 0);
	glBegin(GL_LINES);
	glVertex3f(10, 0, 0);    // First endpoint of line
	glVertex3f(-10, 0, 0);    // Second endpoint of line
	glEnd();
}
void Draw_Info()
{
	if (OBJECT_PAGE)
	{
		if (ObMove == 0)
		{
			PrintStringAt(0, -0.65, -1.4, 1, 0, 0, "Main Object");
			PrintStringAt(0, -0.7, -1.4, 1, 1, 1, VertexToString(&object.Location));
		}
		if (ObMove == 1) 
		{ 
			PrintStringAt(0, -0.65, -1.4, 1, 0, 0, "Object 1"); 
			PrintStringAt(0, -0.7, -1.4, 1, 1, 1, VertexToString(&Ob1.Location));

		}
		if (ObMove == 2)
		{
			PrintStringAt(0, -0.65, -1.4, 1, 0, 0, "Object 2");
			PrintStringAt(0, -0.7, -1.4, 1, 1, 1, VertexToString(&Ob2.Location));

		}
		PrintStringAt(0, -0.6, -1.4, 1, 1, 1, "Adding : 1/");
		itoa(ForAdd, buff, 10);
		PrintStringAt(0.22, -0.6, -1.4, 1, 1, 1, buff);
		PrintStringAt(0.8, -0.6, -1.4, 1, 1, 1, "Boxs : ");
		itoa(object.Box_Count, buff, 10);
		PrintStringAt(0.95, -0.6, -1.4, 1, 1, 1, buff);
		PrintStringAt(0.8, -0.65, -1.4, 1, 1, 1, "Index : ");
		itoa(object.BoxIndex, buff, 10);
		PrintStringAt(0.95, -0.65, -1.4, 1, 1, 1, buff);
		PrintStringAt(-0.7, -0.6, -1.4, 1, 1, 1, "x            y            z");
		PrintStringAt(-1.0, -0.65, -1.4, 1, 1, 1, "Location : ");
		if (VertexOption == 1)PrintStringAt(-0.7, -0.65, -1.4, 1, 0, 0, VertexToString(&object.box[object.BoxIndex].Location));
		else PrintStringAt(-0.7, -0.65, -1.4, 1, 1, 1, VertexToString(&object.box[object.BoxIndex].Location));
		PrintStringAt(-1.0, -0.7, -1.4, 1, 1, 1, "Rotation : ");
		if (VertexOption == 2)PrintStringAt(-0.7, -0.7, -1.4, 1, 0, 0, VertexToString(&object.box[object.BoxIndex].Rotation));
		else PrintStringAt(-0.7, -0.7, -1.4, 1, 1, 1, VertexToString(&object.box[object.BoxIndex].Rotation));
		PrintStringAt(-1.0, -0.75, -1.4, 1, 1, 1, "Size     : ");
		PrintStringAt(-1.0, -0.8, -1.4, 1, 1, 1, "Color    : ");

		if (object.Box_Count > 0)
		{
			if (VertexOption == 3) PrintStringAt(-0.7, -0.75, -1.4, 1, 0, 0, VertexToString(&object.box[object.BoxIndex].Size));
			else PrintStringAt(-0.7, -0.75, -1.4, 1, 1, 1, VertexToString(&object.box[object.BoxIndex].Size));
			if (VertexOption == 4) PrintStringAt(-0.7, -0.8, -1.4, 1, 0, 0, VertexToString(&object.box[object.BoxIndex].Color));
			else PrintStringAt(-0.7, -0.8, -1.4, 1, 1, 1, VertexToString(&object.box[object.BoxIndex].Color));
		}
		else
		{
			PrintStringAt(-0.7, -0.75, -1.4, 1, 1, 1, "0            0            0");
			PrintStringAt(-0.7, -0.8, -1.4, 1, 1, 1, "0            0            0");
		}
	}
	if (MAP_PAGE)
	{
		PrintStringAt(0, -0.7, -1.4, 1, 1, 1, to_string(-CameraX).c_str());
		PrintStringAt(0.2, -0.7, -1.4, 1, 1, 1, to_string(-CameraY).c_str());
		PrintStringAt(0.4, -0.7, -1.4, 1, 1, 1, to_string(-CameraZ).c_str());
		if (polymore)glColor3f(0, 10, 0);
		else glColor3f(10, 0, 0);
		PrintStringAt(0.4, -0.75, -1.4, 1, 1, 1, (polymore == 1) ? "Poly Ture" : "Poly False");
		PrintStringAt(-1.0, -0.65, -1.4, 1, 1, 1, ("Plan Index = " + to_string(PlanIndex)).c_str());
		if (Difficult == 0)PrintStringAt(-1.0, -0.75, -1.4, 1, 1, 1, "Difficult : Easy");
		if (Difficult == 1)PrintStringAt(-1.0, -0.75, -1.4, 1, 1, 1, "Difficult : Mid");
		if (Difficult == 2)PrintStringAt(-1.0, -0.75, -1.4, 1, 1, 1, "Difficult : Hard");
		if (Plan == 0)PrintStringAt(-1.0, -0.7, -1.4, 1, 1, 1, "Plan : Deffend");
		if (Plan == 1)PrintStringAt(-1.0, -0.7, -1.4, 1, 1, 1, "Plan : Mid");
		if (Plan == 2)PrintStringAt(-1.0, -0.7, -1.4, 1, 1, 1, "Plan : Attack");
	}
}
void DrawFrame()
{
	glLineWidth(4);
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex3f(-3.95, 4, -5);
	glVertex3f(-3.95, -4, -5);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(4.15, 4, -5);
	glVertex3f(4.15, -4, -5);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(4.15, -1.9, -5);
	glVertex3f(-3.95, -1.9, -5);
	glEnd();
	glLineWidth(1);

	if (OBJECT_PAGE) {
		RotateLeft.Draw_Button();
		RotateRight.Draw_Button();
		SaveObject.Draw_Button();
		LoadObject.Draw_Button();
		TypeObject.Draw_Button();
		HideShowAxis.Draw_Button();
		SetMove.Draw_Button();
		MoveIdle.Draw_Button();
		Convert.Draw_Button();
		RotateBuild.Draw_Button();
		OBBtn1.Draw_Button();
		OBBtn2.Draw_Button();
	}
	if(MAP_PAGE)
	{
		NextList.Draw_Button();
		NextOptionList.Draw_Button();
		for (int i = 0; i < 10; i++)
			BuildingBtn[i + List * 10].Draw_Button();

		for (int i = 8 * Option_List; i < (8 * Option_List) + 8; i++)
			Buildings_Option[i].Draw_Button();
	}
}
void DrawSetButtons()
{

	PrintStringAt(-0.6, 2.5, -5, 1, 0, 0, "Location");
	PrintStringAt(-0.6, 2.3, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, 1.0, -5, 1, 0, 0, "Rotation");
	PrintStringAt(-0.6, 0.8, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, -0.5, -5, 1, 0, 0, "Size");
	PrintStringAt(-0.6, -0.7, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, -2.0, -5, 1, 0, 0, "Color");
	PrintStringAt(-0.6, -2.2, -5, 1, 0, 0, "Speed");

	AblyMove.Draw_Button();
	SetMove.Draw_Button();
	BackMove.Draw_Button();

	LFX.Draw_Button();
	LTX.Draw_Button();
	LFY.Draw_Button();
	LTY.Draw_Button();
	LFZ.Draw_Button();
	LTZ.Draw_Button();
	LS.Draw_Button();

	RFX.Draw_Button();
	RTX.Draw_Button();
	RFY.Draw_Button();
	RTY.Draw_Button();
	RFZ.Draw_Button();
	RTZ.Draw_Button();
	RS.Draw_Button();

	SFX.Draw_Button();
	STX.Draw_Button();
	SFY.Draw_Button();
	STY.Draw_Button();
	SFZ.Draw_Button();
	STZ.Draw_Button();
	SS.Draw_Button();

	CFX.Draw_Button();
	CTX.Draw_Button();
	CFY.Draw_Button();
	CTY.Draw_Button();
	CFZ.Draw_Button();
	CTZ.Draw_Button();
	CS.Draw_Button();
}
void MainPage_PrintFunction()
{

	for (int i = 0; i < Current_Page->BtnsSize; i++)
		Current_Page->Btns[i]->Draw_Button();
	PrintStringAt(0.5,1.5,-5,10,10,0,"<---- Input Name");
}
void MapPage_PrintFunction()
{
	Draw_Info();
	DrawFrame();
	glViewport(180, 150, 1200, 720);
	Draw_Axis();
	glTranslatef(CameraX, CameraY, CameraZ);
	Stations[0].Draw(0);
	Stations[1].Draw(0);
	Stations[2].Draw(0);
	Level_Build[0].Draw(0);
	Level_Build[1].Draw(0);
	Stations[2].Draw(0);
	for (int i = 0; i < 30; i++)
		for (int j = 0; j < 50; j++)
		{
			glTranslatef(2 * i, 0, 2 * j);
			glColor3f(0, 0.7 + float(((i + j) % 10)) / 10, 0);
			glBegin(GL_QUADS);
			glVertex3f(-1, 0, -1);
			glVertex3f(1, 0, -1);
			glVertex3f(1, 0, 1);
			glVertex3f(-1, 0, 1);
			glEnd();
			glTranslatef(-2 * i, 0, -2 * j);
		}

	for (int i = 0; i < 100; i++)
	{
		Building[i].Draw(0);
		if (Building[i].Box_Count > 0)
		{
			PrintStringAt(Building[i].Location.x, 7, Building[i].Location.z, 1, 0, 0, to_string(i).c_str());
			PrintStringAt(Building[i].Location.x, 6, Building[i].Location.z, 1, 0, 0, "|");
			PrintStringAt(Building[i].Location.x, 5, Building[i].Location.z, 1, 0, 0, "|");
			PrintStringAt(Building[i].Location.x, 4, Building[i].Location.z, 1, 0, 0, "|");
			PrintStringAt(Building[i].Location.x, 3, Building[i].Location.z, 1, 0, 0, "|");
		}
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			if (PlansIn[i][j] == 1 && Plan == i)
			{
				string str;
				if (i == 0)str = to_string(j) + " -Deffend";
				if (i == 1)str = to_string(j) + " -Mid";
				if (i == 2)str = to_string(j) + " -Attack";

				PrintStringAt(Plans[Difficult][i][j][0], 0.5, Plans[Difficult][i][j][1], 0, 0, 10, str.c_str());
				PrintStringAt(Plans[Difficult][i][j][0], 0, Plans[Difficult][i][j][1], 0, 0, 10, "|");
				PrintStringAt(Plans[Difficult][i][j][0], 1, Plans[Difficult][i][j][1], 0, 0, 10, "|");
				PrintStringAt(Plans[Difficult][i][j][0], 1.5, Plans[Difficult][i][j][1], 0, 0, 10, "|");
				PrintStringAt(Plans[Difficult][i][j][0], 2, Plans[Difficult][i][j][1], 0, 0, 10, "|");
				PrintStringAt(Plans[Difficult][i][j][0], 2, Plans[Difficult][i][j][1], 0, 0, 10, "|");
				if (Plans[Difficult][i][j][2] == 1)
					PrintStringAt(Plans[Difficult][i][j][0], 2.5, Plans[Difficult][i][j][1], 0, 0, 10, "SHELL TANK");
				if (Plans[Difficult][i][j][2] == 2)
					PrintStringAt(Plans[Difficult][i][j][0], 2.5, Plans[Difficult][i][j][1], 0, 0, 10, "GUN TANK");
				if (Plans[Difficult][i][j][2] == 3)
					PrintStringAt(Plans[Difficult][i][j][0], 2.5, Plans[Difficult][i][j][1], 0, 0, 10, "MISSILE TANK");
				if (Plans[Difficult][i][j][2] == 4)
					PrintStringAt(Plans[Difficult][i][j][0], 2.5, Plans[Difficult][i][j][1], 0, 0, 10, "HEAVY TANK");
			}
		}
	}
	glViewport(0, 0, WIDTH, HEIGHT);
}
void ObjectPage_PrintFunction()
{
	Draw_Info();
	DrawFrame();
	for (int i = 0; i < Current_Page->BtnsSize; i++)
		Current_Page->Btns[i]->Draw_Button();
	glViewport(180, 150, 1200, 720);
	Draw_Axis();

	glRotatef(Rotateing, 0, 1, 0);
	object.Draw(Showing* HideRestNum);
	Ob1.Draw(0);
	Ob2.Draw(0);
	glRotatef(Rotateing, 0, -1, 0);
	glViewport(0, 0, WIDTH, HEIGHT);

}
void MovementPage_PrintFunction()
{
	PrintStringAt(-0.6, 2.5, -5, 1, 0, 0, "Location");
	PrintStringAt(-0.6, 2.3, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, 1.0, -5, 1, 0, 0, "Rotation");
	PrintStringAt(-0.6, 0.8, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, -0.5, -5, 1, 0, 0, "Size");
	PrintStringAt(-0.6, -0.7, -5, 1, 0, 0, "Speed");
	PrintStringAt(-0.6, -2.0, -5, 1, 0, 0, "Color");
	PrintStringAt(-0.6, -2.2, -5, 1, 0, 0, "Speed");
	for (int i = 0; i < Current_Page->BtnsSize; i++)
		Current_Page->Btns[i]->Draw_Button();
}
void ExitPage_PrintFunction()
{
	for (int i = 0; i < Current_Page->BtnsSize; i++)
		Current_Page->Btns[i]->Draw_Button();
}

void draw()
{
	glClear(GL_COLOR_BUFFER_BIT |
		GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	Current_Page->Show();

	glutSwapBuffers();			// display the output
}
void idle()
{
	//return;
	if (MoveingIdle)
		object.move();
	Rotateing += RotateFlag;
	Rotateing %= 360;
	draw();
}
// Set OpenGL parameters
void init()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 0, 0, 300);
	glMatrixMode(GL_MODELVIEW);

	// Lighting parameters
	GLfloat mat_ambdif[] = { 1, 1, 1, 0 };
	GLfloat mat_specular[] = { 1, 1, 1, 0.0 };
	GLfloat mat_diffuseLight[] = { 1,1,1,0 };
	GLfloat mat_shininess[] = { 80.0 };
	GLfloat light_position[] = { 1, 1, 1, 0.0 };
	glClearColor(0.3, 0.3, 1.0, 0.0);

	glMaterialfv(GL_LIGHT0, GL_AMBIENT, mat_ambdif);
	glMaterialfv(GL_LIGHT0, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_LIGHT0, GL_SHININESS, mat_shininess);
	glMaterialfv(GL_LIGHT0, GL_DIFFUSE, mat_diffuseLight);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);

	MainPage.AddButton(BuildObject.init(0, 2.5, 0.5, 1, 1, 1, "Object Editor"));
	MainPage.AddButton(BuildMap.init(0, 2, 0.5, 1, 1, 1, "Map Editor"));
	MainPage.AddButton(ExitButton.init(0, -2.5, 0.5, 5, 0, 0, "Exit"));
	MainPage.AddButton(SaveMap.init(0, 0.5, 0.5, 1, 1, 1, "Save Map"));
	MainPage.AddButton(LoadMap.init(0, 0.0, 0.5, 1, 1, 1, "Load Map"));
	MainPage.AddButton(SavePlans.init(0, 1.0, 0.5, 1, 1, 1, "SavePlans"));

	ExitPage.AddButton(YES.init(-1, 0, 0.5, 0, 0, 0, "Yes"));
	ExitPage.AddButton(NO.init(1, 0, 0.5, 1, 0, 0, "No"));

	ObjectPage.AddButton(HideRest.init(-4.5, 2.5, 0.5, 1, 0.5, 0.5, "HideRest"));
	ObjectPage.AddButton(Convert.init(-4.5, -2.5, 0.5, 1, 0.5, 0.5, "Convert"));
	ObjectPage.AddButton(SaveObject.init(-4.5, -1.0, 0.5, 1, 1, 1, "SaveObject"));
	ObjectPage.AddButton(LoadObject.init(-4.5, -1.5, 0.5, 1, 1, 1, "LoadObject"));
	ObjectPage.AddButton(TypeObject.init(-4.5, -2.0, 0.5, 1, 1, 1, ""));
	ObjectPage.AddButton(AblyMove.init(4.7, 2, 0.45, 1, 1, 1, "AblyMove"));

	MainPage.AddButton(TypeObject.init(0, 1.5, 0.5, 1, 1, 1, ""));


	ObjectPage.AddButton(RotateLeft.init(-4.5, 2.0, 0.5, 1, 1, 1, "<<"));
	ObjectPage.AddButton(RotateRight.init(-4.5, 1.5, 0.5, 1, 1, 1, ">>"));
	ObjectPage.AddButton(HideShowAxis.init(-4.5, 1.0, 0.5, 1, 1, 1, "Axis-On/Off"));
	ObjectPage.AddButton(RotateBuild.init(-4.5, 0.5, 0.5, 1, 1, 1, "Rotate : Off"));

	ObjectPage.AddButton(OBBtn0.init(4.7, -1.5, 0.45, 10, 0, 10, "Main Object"));
	ObjectPage.AddButton(OBBtn1.init(4.7, -2.0, 0.45, 10, 0, 10, "Object 1"));
	ObjectPage.AddButton(OBBtn2.init(4.7, -2.5, 0.45, 10, 0, 10, "Object 1"));

	ObjectPage.AddButton(SetMove.init(4.7, 2.5, 0.45, 1, 1, 1, "CreateMove"));
	ObjectPage.AddButton(MoveIdle.init(4.7, 1.0, 0.45, 1, 0, 0, "Move"));


	MovementPage.AddButton(BackMove.init(4.7, 1.5, 0.45, 1, 1, 1, "BackMove"));
	MovementPage.AddButton(ReqMove.init(4.7, 1.0, 0.45, 10, 0, 0, "ReqMove:OFF"));


	MovementPage.AddButton(LFX.init(-3.5, 2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LTX.init(-3.5, 2.0, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LFY.init(-2.5, 2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LTY.init(-2.5, 2.0, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LFZ.init(-1.5, 2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LTZ.init(-1.5, 2.0, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(LS.init(-0.5, 2.0, 0.5, 0, 0, 0, "N"));

	MovementPage.AddButton(RFX.init(-3.5, 1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RTX.init(-3.5, 0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RFY.init(-2.5, 1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RTY.init(-2.5, 0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RFZ.init(-1.5, 1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RTZ.init(-1.5, 0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(RS.init(-0.5, 0.5, 0.5, 0, 0, 0, "N"));

	MovementPage.AddButton(SFX.init(-3.5, -0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(STX.init(-3.5, -1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(SFY.init(-2.5, -0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(STY.init(-2.5, -1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(SFZ.init(-1.5, -0.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(STZ.init(-1.5, -1, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(SS.init(-0.5, -1, 0.5, 0, 0, 0, "N"));

	MovementPage.AddButton(CFX.init(-3.5, -2, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CTX.init(-3.5, -2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CFY.init(-2.5, -2, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CTY.init(-2.5, -2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CFZ.init(-1.5, -2, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CTZ.init(-1.5, -2.5, 0.5, 0, 0, 0, ""));
	MovementPage.AddButton(CS.init(-0.5, -2.5, 0.5, 0, 0, 0, "N"));

	Stations[0].Load_Project("Station");
	Stations[1].Load_Project("Station");
	Stations[2].Load_Project("Station");

	Level_Build[0].Load_Project("Level_1");
	Level_Build[1].Load_Project("Level_1");

	Level_Build[0].Location.Set_(30, 0, 95);
	Level_Build[1].Location.Set_(30, 0, 5);

	Stations[0].Location.Set_(4, 0, 50);
	Stations[1].Location.Set_(29, 0, 50);
	Stations[2].Location.Set_(54, 0, 50);
	string BtnName;
	float BtnY = 2.5;
	for (int i = 0; i < 100; i++)
	{
		BtnName = "B" + to_string(i);
		MapPage.AddButton(BuildingBtn[i].init(-4.5, BtnY, 0.5, 1, 1, 1, BtnName.c_str()));
		BtnY -= 0.5;
		if (BtnY == -2.5)BtnY = 2.5;
	}

	MapPage.AddButton(NextList.init(-4.5, -2.5, 0.5, 1, 1, 1, "List"));
	MapPage.AddButton(NextOptionList.init(4.7, -2.0, 0.5, 1, 1, 1, "Next"));

	Option_Y = 2.5;
	string filename("Buildings.txt");
	ifstream IF(filename);
	while (getline(IF, filename)) {
		MapPage.AddButton(Buildings_Option[Options_Count].init(4.7, Option_Y, 0.5, 1, 1, 1, ""));
		strcpy(Buildings_Option[Options_Count++].str, filename.c_str());
		Option_Y -= 0.5;
		if (Option_Y < -1.0)Option_Y = 2.5;
	}
	IF.close();
	TypeBtn = &TypeObject;
	Current_Page = &MainPage;
	MainPage.Back = &ExitPage;
	ExitPage.Back = NULL;
	MapPage.Back = &MainPage;
	ObjectPage.Back = &MainPage;
	MovementPage.Back = &ObjectPage;

	MainPage.SetPrintFuction(&MainPage_PrintFunction);
	MapPage.SetPrintFuction(&MapPage_PrintFunction);
	ObjectPage.SetPrintFuction(&ObjectPage_PrintFunction);
	MovementPage.SetPrintFuction(&MovementPage_PrintFunction);
	ExitPage.SetPrintFuction(&ExitPage_PrintFunction);
}
int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);	// RGB display, double-buffered, with Z-Buffer
	glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(10, 10);
	glutCreateWindow("3D");
	glutReshapeFunc(reshape);
	glutDisplayFunc(draw);						// Set the display function
	glutKeyboardFunc(keyboard);					// Set the keyboard function
	glutIdleFunc(idle);
	glutMouseFunc(glutMouseClick);
	glutFullScreen();
	glutPassiveMotionFunc(passiveMotionFunc);
	init();

	glutMainLoop();							// Start the main event loop
}