#include "Box.cpp"

class Object : public LocationAble, public RotationAble
{
public:
	Box box[30];
	int BoxIndex, Box_Count;
	int HideArrows;
	Box* Copied;
	int Object_Index, Object_Count;
	string ObjName;
	Object()
	{
		BoxIndex = Box_Count = Object_Count = Object_Index = 0;
		HideArrows = 1;
		Copied = NULL;
	}
	void Draw(int Hide)
	{
		Go_Location();
		Rotation_Open(1, 1, 1);
		for (int i = 0; i < Box_Count; i++)
		{
			if (i == BoxIndex % Box_Count && HideArrows == 0)
			{
				glColor3f(10, 0, 0);
				box[i].Go_Location();
				glBegin(GL_LINES);
				glVertex3f(-5, 0, 0);
				glVertex3f(5, 0, 0);
				glEnd();
				glBegin(GL_LINES);
				glVertex3f(0, 0, -5);
				glVertex3f(0, 0, 5);
				glEnd();
				glBegin(GL_LINES);
				glVertex3f(0, 5, 0);
				glVertex3f(0, -5, 0);
				glEnd();
				box[i].Back_Location();
			}
			
			if (!Hide) {
				box[i].Draw();
			}
			else
			{
				if (i == BoxIndex)
					box[i].Draw();
				else
				{
					box[i].Go_Location();
					box[i].Rotation_Open(1, 1, 1);
					box[i].Color.Color_On();
					Draw_Box(&box[i]);
					box[i].Rotation_Close(1, 1, 1);
					box[i].Back_Location();
				}
			}

		}
		Rotation_Close(1, 1, 1);
		Back_Location();
	}
	inline void SaveBox() {
		Copied = &box[BoxIndex];
	}
	void CopyBox()
	{
		if (!Copied)return;
		box[Box_Count].Copy(Copied);
		Box_Count++;

	}
	void move()
	{
		for (int i = 0; i < Box_Count; i++)
			box[i].move();

	}
	void Save_Project(string FileName)
	{
		Location.Set_(0, 0, 0);
		string FileTxt = FileName;
		FileTxt += "_Project";
		fstream MyFile;
		MyFile.open(FileTxt, ios::out | ios::binary);
		MyFile.write(reinterpret_cast<char*>(this), sizeof(Object));
		MyFile.close();
		Build(FileName);
	}
	void Load_Project(string FileName)
	{
		string FileTxt = FileName;
		FileTxt += "_Project";

		fstream MyFile;
		MyFile.open(FileTxt, ios::in | ios::binary);
		if (!MyFile)
			return;
		MyFile.read(reinterpret_cast<char*>(this), sizeof(Object));
		MyFile.close();
		ObjName = FileName;
	}
	void RotateBack()
	{
		for (int i = 0; i < Box_Count; i++)
		{
			box[i].Location.x *= -1;
			box[i].Location.z *= -1;
		}
	}
	void RotateRight()
	{
		float x, z, lx, lz, px, pz;
		for (int i = 0; i < Box_Count; i++)
		{
			x = box[i].Size.x;
			z = box[i].Size.z;
			lx = box[i].Location.x;
			lz = box[i].Location.z;
			px = box[i].PlusX;
			pz = box[i].PlusZ;
			box[i].Location.x = lz;
			box[i].Location.z = lx;
			box[i].Size.x = z;
			box[i].Size.z = x;
			box[i].PlusX = pz;
			box[i].PlusZ = px;

		}
	}
	void RotateLeft()
	{
		RotateBack();
		RotateRight();
	}

	void Build(string FileName) {
		Location.Set_(0, 0, 0);
		string FileTxt = FileName;
		FileTxt += "_Bin";
		ofstream MyFile(FileTxt, ios::out | ios::app | ios::binary);
		for (int i = 0; i < Box_Count; i++)
			MyFile.write((char*)&box[i], sizeof(Box));
		MyFile.close();
	}

	void Draw_Box(Box* B)
	{
		float cx, cy, cz;
		cx = B->Size.x / 2;
		cy = B->Size.y / 2;
		cz = B->Size.z / 2;

		glBegin(GL_LINE_LOOP);
		// Front
		glVertex3f(-cx, -cy, cz);
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f(cx, -cy, cz);
		glEnd();
		glBegin(GL_LINE_LOOP);
		// Back
		glVertex3f(-cx, -cy, -cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));
		glEnd();
		glBegin(GL_LINE_LOOP);
		// Left side
		glVertex3f(-cx, -cy, cz);
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-cx, -cy, -cz);
		glEnd();
		glBegin(GL_LINE_LOOP);
		// Right side
		glVertex3f(cx, -cy, cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));
		glEnd();
		glBegin(GL_LINE_LOOP);
		// Up side
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));
		glEnd();
		glBegin(GL_LINE_LOOP);
		// down side
		glVertex3f(cx, -cy, cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f(-cx, -cy, -cz);
		glVertex3f(-cx, -cy, cz);
		glEnd();

	
	}

};

class Page
{
public:
	int BtnsSize;
	Button* Btns[250];
	Page* Back;
	void (*PagePrint)();
	void SetPrintFuction(void (*PagePrint)())
	{
		this->PagePrint = PagePrint;
	}
	void AddButton(Button* btn)
	{
		if (BtnsSize >= 250)return;
		Btns[BtnsSize++] = btn;
	}
	bool AbleButton(Button* btn)
	{
		for (int i = 0; i < BtnsSize; i++)
			if (Btns[i] == btn)return true;
		return false;
	}
	void Show()
	{
		PagePrint();
	}
};