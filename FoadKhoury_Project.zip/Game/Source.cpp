#include "Objects.cpp"
#define PLAYING 1
#define BUILD_COUNT 100
#define TANKS_COUNT 10
#define STARS_COUNT 50
#define BUILDBOX_COUNT 3
#define LEFT_BOUND 1
#define RIGHT_BOUND 2
#define BACK_BOUND 3
#define FRONT_BOUND 4
#define DAWN_BOUND 5
#define UP_BOUND 6
#define BOUND_DISTANCE 0.4

GLfloat density = 0.0; //set the density to 0.3 which is
GLfloat fogColor[4] = { 0, 0, 0, 0.5 }; //set the for

GLfloat b[] = { 30, 1, 50 ,1.0f};


GLsizei WIDTH = 1300, HEIGHT = 1000; // Describes Screen Size
int lx = 0, ly = 5, lz = 15, MouseY, MouseX, Shopping = 0;
float rx, ry, rz, mode = 0;
float ax, az;
float hx, hz, SunDegree = 0;
char InSide = 1;
Box Around[198];
Tank* ConTank;
Helicopter* Heli;
Building MapBuildings[BUILD_COUNT];
Ground ground;
BuildBox BuildBoxes[BUILDBOX_COUNT];

Building Arrow;
Building SpaceShip;

Player Player1, Player2;
Button TanksBtn[10];

Button ShopTankMenu[6];
Button ShopTankOrder[6];

Button ShopTankMenuBack;
Tank ShowTank[4];

Building Coins[50];
Building Repairs[10];
Building Station[3];

D_Vertex From, To;
D_Vertex HeiMoveCamera;

Button Maps[6];
Button Diffecult[3];
Button LevelBtns[3];

Building LevelShows[3];
Star stars[STARS_COUNT];
char CollectingFlag = 0;
char CollectedTanks[10] = {0,0,0,0,0,0,0,0,0,0};

char P1Count=0, P2Count=0;

int BuildsCount = 0;
int LevelChoosen = 1;
int Page=0;

const string Plans[6][9] = {
							   {"Town_EasyDefendPlan.txt"
								,"Town_EasyMidPlan.txt"
								,"Town_EasyAttackPlan.txt"
								,"Town_MidDefendPlan.txt"
								,"Town_MidMidPlan.txt"
								,"Town_MidAttackPlan.txt"
								,"Town_HardDefendPlan.txt"
								,"Town_HardMidPlan.txt"
								,"Town_HardAttackPlan.txt"},

							   {"Desert_EasyDefendPlan.txt"
								,"Desert_EasyMidPlan.txt"
								,"Desert_EasyAttackPlan.txt"
								,"Desert_MidDefendPlan.txt"
								,"Desert_MidMidPlan.txt"
								,"Desert_MidAttackPlan.txt"
								,"Desert_HardDefendPlan.txt"
								,"Desert_HardMidPlan.txt"
								,"Desert_HardAttackPlan.txt"},

							   {"Forest_EasyDefendPlan.txt"
								,"Forest_EasyMidPlan.txt"
								,"Forest_EasyAttackPlan.txt"
								,"Forest_MidDefendPlan.txt"
								,"Forest_MidMidPlan.txt"
								,"Forest_MidAttackPlan.txt"
								,"Forest_HardDefendPlan.txt"
								,"Forest_HardMidPlan.txt"
								,"Forest_HardAttackPlan.txt"},

							   {"TEasy_EasyDefendPlan.txt"
								,"TEasy_EasyMidPlan.txt"
								,"TEasy_EasyAttackPlan.txt"
								,"TEasy_MidDefendPlan.txt"
								,"TEasy_MidMidPlan.txt"
								,"TEasy_MidAttackPlan.txt"
								,"TEasy_HardDefendPlan.txt"
								,"TEasy_HardMidPlan.txt"
								,"TEasy_HardAttackPlan.txt"},

							   {"DEasy_EasyDefendPlan.txt"
								,"DEasy_EasyMidPlan.txt"
								,"DEasy_EasyAttackPlan.txt"
								,"DEasy_MidDefendPlan.txt"
								,"DEasy_MidMidPlan.txt"
								,"DEasy_MidAttackPlan.txt"
								,"DEasy_HardDefendPlan.txt"
								,"DEasy_HardMidPlan.txt"
								,"DEasy_HardAttackPlan.txt"},

							   {"FEasy_EasyDefendPlan.txt"
								,"FEasy_EasyMidPlan.txt"
								,"FEasy_EasyAttackPlan.txt"
								,"FEasy_MidDefendPlan.txt"
								,"FEasy_MidMidPlan.txt"
								,"FEasy_MidAttackPlan.txt"
								,"FEasy_HardDefendPlan.txt"
								,"FEasy_HardMidPlan.txt"
								,"FEasy_MidAttackPlan.txt"} };

void PutBuilding(Building* b);
float Distance(LocationAble* L1, LocationAble* L2)
{
	return sqrt(pow(L1->Location.x - L2->Location.x, 2) + pow(L1->Location.y - L2->Location.y, 2) + pow(L1->Location.z - L2->Location.z, 2));
}

void ChoosePlan(int P1_Needs,int P2_Needs)
{
	int Old=Player2.Plan;
	if (P1_Needs<3 || P1_Needs + 5 > P2_Needs)
		Player2.Plan = ATTACK_PLAN;
	else if (P2_Needs<3 || P2_Needs + 5 > P1_Needs)
		Player2.Plan = DEFEND_PLAN;
	else if( abs(P1_Needs-P2_Needs)<3)
		Player2.Plan = MID_PLAN;
	if (Old != Player2.Plan)
		Player2.ReBuild(&ground);
}
void SendTank(Tank* tank, int gx, int gz)
{
	if (tank->Location.x == gx && tank->Location.z == gz)return;
	ground.Closest(&gx, &gz);
	tank->GetPath(&ground, gx, gz);
	tank->GoX = gx;
	tank->GoZ = gz;
	if (tank->ProtectBy) {
		gz += (tank->Team == 1) ? -1 : 1;
		SendTank(tank->ProtectBy, gx, gz);
	}
}
int SearchBox()
{
	D_Vertex* Col[4] = { NULL,NULL,NULL,NULL };
	int Nums[4] = { -1,-1,-1,-1 };
	for (int i = 1; i < 5; i++)
	{
		if (!Col[0] && Player2.Build.BoxIn[(i - 1) * 4 + 1] == 0)
		{
			Col[0] = &Player2.Build.box[(i - 1) * 4 + 1].Color;
			Nums[0] = (i - 1) * 4 + 1;
		}
		if (!Col[1] && Player2.Build.BoxIn[(i - 1) * 4 + 2] == 0){
			Col[1] = &Player2.Build.box[(i - 1) * 4 + 2].Color;
			Nums[1] = (i - 1) * 4 + 2;
		}
		if (!Col[2] && Player2.Build.BoxIn[(i - 1) * 4 + 3] == 0){
			Col[2] = &Player2.Build.box[(i - 1) * 4 + 3].Color;
			Nums[2] = (i - 1) * 4 + 3;
		}
		if (!Col[3] && Player2.Build.BoxIn[(i - 1) * 4 + 4] == 0){
			Col[3] = &Player2.Build.box[(i - 1) * 4 + 4].Color;
			Nums[3] = (i - 1) * 4 + 4;
		}
	}
	

	for (int j = 0; j < 4; j++)
	{
		if (Col[j])
		{
			int i;
			for (i = 0; i < BUILDBOX_COUNT; i++)
			{
				if (BuildBoxes[i].Status == 0 && Col[j]->x == BuildBoxes[i].box[0].Color.x
					&& Col[j]->y == BuildBoxes[i].box[0].Color.y
					&& Col[j]->z == BuildBoxes[i].box[0].Color.z
					&& BuildBoxes[i].BOUNDED)
				{
					if (Player2.Heli.GetBuildBox)
					{
						if (Distance(&Player2.Heli, Player2.Heli.GetBuildBox) > Distance(&Player2.Heli, &BuildBoxes[i]))
							Player2.Heli.GetBuildBox = &BuildBoxes[i];
					}
					else
						Player2.Heli.GetBuildBox = &BuildBoxes[i];
					Player2.Heli.Status = 1;
				}
			}
			if (Player2.Heli.GetBuildBox)
				return Nums[j];
			
			
		}
	}

	return -1;
}
const char* TankOrder(Tank* T)
{
	switch (T->Order)
	{
	case ATTACK_HELICOPTER:
		return "AT_H";
		break;
	case ATTACK_BASE:
		return "AT_B";
		break;
	case PROTECT_BASE:
		return "PR_B";
		break;
	case PROTECT_TANK:
		return "PR_T";
		break;
	case PROTECT_HELICOPTER:
		return "PR_H";
		break;
	case IDLE_TANK:
		return "IDLE";
		break;
	}
	return "";
}

void PrintStringAt(float x, float y, float z, float r, float g, float b, const char* str)
{
	const char* strP = str;
	glColor3f(r, g, b);
	glRasterPos3f(x, y, z);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));
}
int Box_Bound(Box B1, D_Vertex* L1, Box B2, D_Vertex* L2)
{
	B1.Location.Add(L1);
	B2.Location.Add(L2);
	if (B1.Location.x > (B2.Location.x - B2.Size.x / 2 - B1.Size.x / 2) && B1.Location.x < (B2.Location.x + B2.Size.x / 2 + B1.Size.x / 2))
		if (B1.Location.y > (B2.Location.y - B2.Size.y / 2 - B1.Size.y / 2) && B1.Location.y < (B2.Location.y + B2.Size.y / 2 + B1.Size.y / 2))
			if (B1.Location.z > (B2.Location.z - B2.Size.z / 2 - B1.Size.z / 2) && B1.Location.z < (B2.Location.z + B2.Size.z / 2 + B1.Size.z / 2))
				return 1;
	return 0;
}
int Obj_Bound(BoundAble* B1, BoundAble* B2, D_Vertex* L1, D_Vertex* L2)
{
	if (sqrt(pow(L1->x - L2->x, 2) + pow(L1->y - L2->y, 2) + pow(L1->z - L2->z, 2)) > 10)
		return 0;
	int i, j;
	for (i = 0; i < B1->Box_Count; i++)
		for (j = 0; j < B2->Box_Count; j++)
			if (Box_Bound(B1->box[i], L1, B2->box[j], L2))
				return 1;
	return 0;
}
int testObj_Bound(BoundAble* B1, Building* B2, D_Vertex* L1, D_Vertex* L2)
{
	if (sqrt(pow(L1->x - L2->x, 2) + pow(L1->y - L2->y, 2) + pow(L1->z - L2->z, 2)) > 10)
		return 0;
	int j;
	for (j = 1; j < B2->Box_Count; j++)
		if (Box_Bound(B1->box[0], L1, B2->box[j], L2))
			if (B2->BoxIn[j] == 0 &&
				B2->box[j].Color.x == B1->box[0].Color.x &&
				B2->box[j].Color.y == B1->box[0].Color.y &&
				B2->box[j].Color.z == B1->box[0].Color.z)return j;
	return 0;
}
int Bound_Status(Box B1, D_Vertex* L1, Box B2, D_Vertex* L2)
{
	if (sqrt(pow(L1->x - L2->x, 2) + pow(L1->y - L2->y, 2) + pow(L1->z - L2->z, 2)) > 10)
		return 0;
	B1.Location.Add(L1);
	B2.Location.Add(L2);
	float Loc1, Loc2;
	if (B1.Location.z > B2.Location.z - (B2.Size.z / 2 + B1.Size.z / 2) && B1.Location.z < B2.Location.z + (B2.Size.z / 2 + B1.Size.z / 2))
	{
		if (B1.Location.x > B2.Location.x - (B2.Size.x / 2 + B1.Size.x / 2) && B1.Location.x < B2.Location.x + (B2.Size.x / 2 + B1.Size.x / 2))
		{
			Loc1 = (B1.Location.y - B1.Size.y / 2);
			Loc2 = (B2.Location.y + B2.Size.y / 2);
			if (Loc1<Loc2 && Loc1>Loc2 - BOUND_DISTANCE)
				return DAWN_BOUND;

			Loc1 = (B1.Location.y + B1.Size.y / 2);
			Loc2 = (B2.Location.y - B2.Size.y / 2);
			if (Loc1 > Loc2 && Loc1 < Loc2 + BOUND_DISTANCE)
				return UP_BOUND;
		}
	}
	if (B1.Location.y > B2.Location.y - (B2.Size.y / 2 + B1.Size.y / 2) && B1.Location.y < B2.Location.y + (B2.Size.y / 2 + B1.Size.y / 2))
	{
		if (B1.Location.z > B2.Location.z - (B2.Size.z / 2 + B1.Size.z / 2) && B1.Location.z < B2.Location.z + (B2.Size.z / 2 + B1.Size.z / 2))
		{
			Loc1 = (B1.Location.x - B1.Size.x / 2);
			Loc2 = (B2.Location.x + B2.Size.x / 2);
			if (Loc1<Loc2 && Loc1>Loc2 - BOUND_DISTANCE)
				return LEFT_BOUND;

			Loc1 = (B1.Location.x + B1.Size.x / 2);
			Loc2 = (B2.Location.x - B2.Size.x / 2);
			if (Loc1 > Loc2 && Loc1 < Loc2 + BOUND_DISTANCE)
				return RIGHT_BOUND;
		}
		if (B1.Location.x > B2.Location.x - (B2.Size.x / 2 + B1.Size.x / 2) && B1.Location.x < B2.Location.x + (B2.Size.x / 2 + B1.Size.x / 2))
		{
			Loc1 = (B1.Location.z - B1.Size.z / 2);
			Loc2 = (B2.Location.z + B2.Size.z / 2);
			if (Loc1<Loc2 && Loc1>Loc2 - BOUND_DISTANCE)
				return BACK_BOUND;

			Loc1 = (B1.Location.z + B1.Size.z / 2);
			Loc2 = (B2.Location.z - B2.Size.z / 2);
			if (Loc1 > Loc2 && Loc1 < Loc2 + BOUND_DISTANCE)
				return FRONT_BOUND;
		}
	}
	return 0;
}
void Type_Name(char* str, char ch)
{
	if (strlen(str) > 10)return;
	int i = 0;
	while (*(str + i) != 0)
		i++;
	*(str + (i++)) = ch;
	*(str + i) = 0;
}
void Remove_Char(char* str)
{
	int i = 0;
	if (str == "")return;
	*(str + (strlen(str) - 1)) = 0;
}

void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, (GLfloat)w / (GLfloat)h, 1.0, 300);
	glMatrixMode(GL_MODELVIEW);
	WIDTH = w;
	HEIGHT = h;
}
void DrawLights()
{
	b[0] = Station[0].Location.x; b[1] = 2; b[2] = Station[0].Location.z;
	glLightfv(GL_LIGHT2, GL_POSITION, b);
	glEnable(GL_LIGHT2);

	b[0] = Station[1].Location.x; b[1] = 2; b[2] = Station[1].Location.z;
	glLightfv(GL_LIGHT3, GL_POSITION, b);
	glEnable(GL_LIGHT3);

	b[0] = Station[2].Location.x; b[1] = 2; b[2] = Station[2].Location.z;
	glLightfv(GL_LIGHT4, GL_POSITION, b);
	glEnable(GL_LIGHT4);

	b[0] = Player1.Build.Location.x; b[1] = 2; b[2] = Player1.Build.Location.z;
	glLightfv(GL_LIGHT5, GL_POSITION, b);
	glEnable(GL_LIGHT5);

	b[0] = Player2.Build.Location.x; b[1] = 2; b[2] = Player2.Build.Location.z;
	glLightfv(GL_LIGHT6, GL_POSITION, b);
	glEnable(GL_LIGHT6);

	b[0] = Player1.Heli.Location.x;
	b[1] = Player1.Heli.Location.y;
	b[2] = Player1.Heli.Location.z-1.5;
	glLightfv(GL_LIGHT7, GL_POSITION, b);
	glEnable(GL_LIGHT7);
}

void passiveMotionFunc(int x, int y)
{
	if(Page==PLAYING)
	{
		if (Shopping)return;
		if (!mode) {
			if (MouseX < x && Heli->Rotation.z < 25) {
				Heli->Rotation.z += 1;
				if (hx > -2) hx -= 0.1;
				else hx = -2;
			}
			if (MouseX > x && Heli->Rotation.z > -25) {
				Heli->Rotation.z -= 1;
				if (hx < 2) hx += 0.1;
				else hx = 2;
			}
			if (MouseY < y && Heli->Rotation.x >-25) {
				Heli->Rotation.x -= 1;
			}
			if (MouseY > y && Heli->Rotation.x < 25) {
				Heli->Rotation.x += 1;
			}
		}
		else
		{

			if (MouseX < x && Arrow.Location.x < 59)
			{
				Arrow.Location.x += 0.25;
				if (ax > -12) ax -= 0.25;
				else ax = -12;
			}
			if (MouseX > x && Arrow.Location.x > 1) 
			{
				Arrow.Location.x -= 0.25;
				if (ax < 12) ax += 0.25;
				else ax = 12;
			}
			if (MouseY < y && Arrow.Location.z < 99) 
			{
				Arrow.Location.z += 0.25;
				if (az > -12) az -= 0.25;
				else az = -12;
			}
			if (MouseY > y && Arrow.Location.z > 1)
			{
				Arrow.Location.z -= 0.25;
				if (az < 12) az += 0.25;
				else az = 12;
			}
		}
		SetCursorPos(20, 20);
		MouseX = 20;
		MouseY = 20;
	}
}
void glutMouseClick(int btn, int state, int x, int y)
{
	
	if (state != GLUT_DOWN)return;
	
	if (Page != PLAYING)
	{
		int flag = 0;
		BuildsCount = 0;
		if (Maps[0].Clicked(x, y))flag = 1;
		if (Maps[1].Clicked(x, y))flag = 2;
		if (Maps[2].Clicked(x, y))flag = 3;
		if (Maps[3].Clicked(x, y))flag = 4; 
		if (Maps[4].Clicked(x, y))flag = 5; 
		if (Maps[5].Clicked(x, y))flag = 6; 
		
		if (flag)
		{
			glDisable(GL_LIGHT0);

			glutSetCursor(GLUT_CURSOR_NONE);
			string filename;
			if (flag == 1)filename = "FineMap1.txt";
			if (flag == 2)filename = "Desert.txt";
			if (flag == 3)filename = "Forest.txt";
			if (flag == 4)filename = "TownEasy.txt";
			if (flag == 5)filename = "DesertEasy.txt";
			if (flag == 6)filename = "ForestEasy.txt";
			Player1.PickBuild(1, 30, 10, 95, 180, "Level_1", 1);
			Player2.PickBuild(1, 30, 10, 5, 0, "Level_1", 2);
			Heli = &Player1.Heli;
			glutSetCursor(GLUT_CURSOR_NONE);
			for (int i = 0; i < 30; i++)
				for (int j = 0; j < 50; j++)
					ground.Area[i][j].Status = 1;
			string BuildName;
			ifstream input_file(filename);
			int i = 0, BoxCnt;
			float inputX, inputY, inputZ;
			while (getline(input_file, filename)) {
				stringstream data(filename);
				data >> BoxCnt >> inputX >> inputY >> inputZ >> BuildName;
				MapBuildings[i].PickBuild(BoxCnt, BuildName);
				MapBuildings[i].Location.Set_(inputX, inputY, inputZ);
				PutBuilding(&MapBuildings[i]);
				i++;
			}
			input_file.close();
			BuildsCount = i;
			Page = PLAYING;
			for (int i = 0; i < BUILDBOX_COUNT; i++)
			{
				Station[i].PickBuild(10, "Station");
				Station[i].Location.Set_(4 + 25 * i + (i == 1), 0, 50);
				PutBuilding(&Station[i]);
				if (i == 0) BuildBoxes[i].PickBuild("RedBox");
				if (i == 1) BuildBoxes[i].PickBuild("YellowBox");
				if (i == 2) BuildBoxes[i].PickBuild("BlueBox");
				BuildBoxes[i].Location.Set_(4 + 25 * i, 10, 50);
				BuildBoxes[i].box[0].LocationFrom.Set_(4 + 25 * i, 10, 50);
			}

			for (int i = 0; i < 50; i++)
			{
				Coins[i].PickBuild(2, "Coin");
				Coins[i].Location.Set_(5 + ((i + 1) % 10) * 5, 20, 5 + (i / 10) * 20);
				Coins[i].Status = 1;
			}
			for (int i = 0; i < 10; i++)
			{
				Repairs[i].PickBuild(4, "Tool");
				Repairs[i].Location.Set_(30, 20, 5 + i * 10);
				Repairs[i].Status = 1;
			}
			if (flag )
			{
				for (int k = 0; k < 9; k++)
				{
					input_file.open(Plans[flag-1][k]);
					i = 0;
					while (getline(input_file, filename))
					{
						stringstream data(filename);
						data >> Player2.TanksSetTest[k/3][k % 3][i][0];
						data >> Player2.TanksSetTest[k/3][k % 3][i][1];
						data >> Player2.TanksSetTest[k/3][k % 3][i][2];
						i++;
					}
					input_file.close();
				}
			}
			switch (flag)
			{
				case 1:
				case 3:
				case 4:
				case 6:
					ground.PickBuild(1);
					for (int i = 0; i < 198; i++)Around[i].Color.Set_((float)(rand() % 2) / 10, (float)(rand() % 5) / 10, (float)(rand() % 2) / 10);
					break;
				case 2:	
				case 5:	
					ground.PickBuild(2);
					for (i = 0; i < 198; i++)Around[i].Color.Set_(0.5 + (float)(rand() % 5) / 10, 0.5 + (float)(rand() % 5) / 10, 0);
					break;
			}
			return;
		}
		if (Diffecult[0].Clicked(x, y)) { 

			Player2.Difficult = EASY_BOT; 
			Player2.DifficultSpeed = 500; 
		}
		if (Diffecult[1].Clicked(x, y)) { 
			Player2.Difficult = MID_BOT; 
			Player2.DifficultSpeed = 250;
		}
		if (Diffecult[2].Clicked(x, y)) { 
			Player2.Difficult = HARD_BOT;
			Player2.DifficultSpeed = 100;
		}

		if (LevelBtns[0].Clicked(x, y)) { LevelChoosen = 1; }
		if (LevelBtns[1].Clicked(x, y)) { LevelChoosen = 2; }
		if (LevelBtns[2].Clicked(x, y)) { LevelChoosen = 3; }
	}
	if (Page == PLAYING) {
		if (Shopping)
		{
			if (ShopTankMenuBack.Clicked(x, y))
			{
				glutSetCursor(GLUT_CURSOR_NONE);
				glClearColor(0, 0, 0, 0.0);

				Shopping = 0;
			}
			if (ShopTankMenu[0].Clicked(x, y))Player1.BuyTank(1, &ground);
			if (ShopTankMenu[1].Clicked(x, y))Player1.BuyTank(2, &ground);
			if (ShopTankMenu[2].Clicked(x, y))Player1.BuyTank(3, &ground);
			if (ShopTankMenu[3].Clicked(x, y))Player1.BuyTank(4, &ground);
			return;
		}
		if (mode)
		{
			int i;
			for (i = 0; i < 10; i++)
			{
				if (Player1.TanksIn[i] &&
					Obj_Bound(&Arrow, &Player1.Tanks[i], &Arrow.Location, &Player1.Tanks[i].Location))
				{
					if (btn == GLUT_LEFT_BUTTON)
					{
						ConTank = &Player1.Tanks[i];
						return;
					}
					if (btn == GLUT_RIGHT_BUTTON && ConTank && ConTank != &Player1.Tanks[i])
					{
						ConTank->Protect_Tank(&Player1.Tanks[i]);
						return;
					}
				}
				if (Player2.TanksIn[i] &&
					Obj_Bound(&Arrow, &Player2.Tanks[i], &Arrow.Location, &Player2.Tanks[i].Location))
				{
					if (btn == GLUT_LEFT_BUTTON)
					{
						if (ConTank && !CollectingFlag)
						{
							if (ConTank->Type == 1 || ConTank->Type == 4)
								ConTank->OrderTarget = &Player2.Tanks[i];
						}
						if (!CollectingFlag)
						{
							for (int j = 0; j < 10; j++)
								if (CollectedTanks[j])
								{
									if (Player1.Tanks[j].Type == 1 || Player1.Tanks[j].Type == 4)
										Player1.Tanks[j].OrderTarget = &Player2.Tanks[i];
								}
						}
						return;
					}
				}
			}
			if (i == 10 && ConTank && ConTank->Protect && btn == GLUT_RIGHT_BUTTON) {
				ConTank->Order = IDLE_TANK;
				ConTank->Protect->ProtectBy = NULL;
				ConTank->Protect = NULL;
				return;
			}
			if (ConTank && !CollectingFlag) {
				if (btn == GLUT_RIGHT_BUTTON) {
					ConTank = NULL;
					for (int i = 0; i < 10; i++)
						CollectedTanks[i] = 0;
					return;
				}

				ConTank->Order = IDLE_TANK;
				ConTank->OrderTarget = NULL;
				int gx, gz;
				gx = ((int)Arrow.Location.x / 2);
				gz = ((int)Arrow.Location.z / 2);
				SendTank(ConTank, gx, gz);
				return;
			}

			CollectingFlag = !CollectingFlag;

			if (!CollectingFlag)
			{
				int xs, xb, zs, zb;
				xs = (Arrow.Location.x < From.x) ? Arrow.Location.x : From.x;
				xb = (Arrow.Location.x > From.x) ? Arrow.Location.x : From.x;
				zs = (Arrow.Location.z < From.z) ? Arrow.Location.z : From.z;
				zb = (Arrow.Location.z > From.z) ? Arrow.Location.z : From.z;
				for (int i = 0; i < 10; i++)
				{
					if (Player1.TanksIn[i] && Player1.Tanks[i].Location.x > xs
						&& Player1.Tanks[i].Location.x < xb
						&& Player1.Tanks[i].Location.z > zs
						&& Player1.Tanks[i].Location.z < zb)
					{
						CollectedTanks[i] = 1;
					}
				}
				return;
			}
			if (CollectingFlag)
			{
				From.Set_(Arrow.Location.x, Arrow.Location.y, Arrow.Location.z);
				int gx, gz;
				gx = ((int)Arrow.Location.x / 2);
				gz = ((int)Arrow.Location.z / 2);
				for (int i = 0; i < 10; i++, gz)
					if (CollectedTanks[i] == 1)
					{
						Player1.Tanks[i].Order = IDLE_TANK;
						Player1.Tanks[i].OrderTarget = NULL;
						SendTank(&Player1.Tanks[i], gx, gz--);
						CollectedTanks[i] = 0;
						CollectingFlag = 0;
					}
				return;
			}


		}
	}

}
void keyboard(unsigned char key, int x, int y)
{
	if (Page == PLAYING && key==27)
	{
		glutSetCursor(GLUT_CURSOR_LEFT_ARROW);
		glEnable(GL_LIGHT0);
		glClearColor(0.1, 0.1, 0.3, 0.0);
		Page = 0;
		return;
	}
	int j;
	if (key == 'n')
	{
		for(int i=1;i<17;i++)
			if (Player1.Build.BoxIn[i] == 0)
			{
				Player1.Build.BoxIn[i] = 1;
				Player1.Count++;
				j = Player2.Plan;
				if (Player1.Need() + 6 < Player2.Need())
					Player2.Plan = ATTACK_PLAN;
				if (Player1.Need() < Player2.Need() && Player1.Need() <= 2)
					Player2.Plan = ATTACK_PLAN;
				if (Player2.Need() + 6 < Player1.Need())
					Player2.Plan = MID_PLAN;
				if (Player2.Need() + 4 < Player1.Need() && Player2.Need() <= 2)
					Player2.Plan = DEFEND_PLAN;
				if (j != Player2.Plan)
					Player2.ReBuild(&ground);
				break;
			}
	}
	if (key == 'N')
	{
		for (int i = 1; i < 17; i++)
			if (Player1.Build.BoxIn[i] == 1)
			{
				Player1.Build.BoxIn[i] = 0;
				Player1.Count--;
				j = Player2.Plan;
				if (Player1.Need() + 6 < Player2.Need())
					Player2.Plan = ATTACK_PLAN;
				if (Player1.Need() < Player2.Need() && Player1.Need() <= 2)
					Player2.Plan = ATTACK_PLAN;
				if (Player2.Need() + 6 < Player1.Need())
					Player2.Plan = MID_PLAN;
				if (Player2.Need() + 4 < Player1.Need() && Player2.Need() <= 2)
					Player2.Plan = DEFEND_PLAN;
				if (j != Player2.Plan)
					Player2.ReBuild(&ground);
				break;
			}
	}
	if (key == 'k')
	{
		for (int i = 1; i < 17; i++)
			if (Player2.Build.BoxIn[i] == 0)
			{
				Player2.Build.BoxIn[i] = 1;
				Player2.Count++;
				j = Player2.Plan;
				if (Player1.Need() + 6 < Player2.Need())
					Player2.Plan = ATTACK_PLAN;
				if (Player1.Need() < Player2.Need() && Player1.Need() <= 2)
					Player2.Plan = ATTACK_PLAN;
				if (Player2.Need() + 6 < Player1.Need())
					Player2.Plan = MID_PLAN;
				if (Player2.Need() + 4 < Player1.Need() && Player2.Need() <= 2)
					Player2.Plan = DEFEND_PLAN;
				if (j != Player2.Plan)
					Player2.ReBuild(&ground);
				break;
			}
	}
	if (key == 'K')
	{
		for (int i = 1; i < 17; i++)
			if (Player2.Build.BoxIn[i] == 1)
			{
				Player2.Build.BoxIn[i] = 0;
				Player2.Count--;
				j = Player2.Plan;
				if (Player1.Need() + 6 < Player2.Need())
					Player2.Plan = ATTACK_PLAN;
				if (Player1.Need() < Player2.Need() && Player1.Need() <= 2)
					Player2.Plan = ATTACK_PLAN;
				if (Player2.Need() + 6 < Player1.Need())
					Player2.Plan = MID_PLAN;
				if (Player2.Need() + 4 < Player1.Need() && Player2.Need() <= 2)
					Player2.Plan = DEFEND_PLAN;
				if (j != Player2.Plan)
					Player2.ReBuild(&ground);
				break;
			}
	}
	if (key == '+')Arrow.Location.y += 5;
	if (key == '-')Arrow.Location.y -= 5;
	if (key == 'D')SearchBox();
	if (key == 'R')Heli->DropBox();
	if (key == 'X')Heli->AirStop=!Heli->AirStop;
	if (key == 'Z')InSide = !InSide;
	if (key == 'B')
	{
		glClearColor(0.3, 0.3, 1.0, 0.0);
		Shopping = 1;
		glutSetCursor(GLUT_CURSOR_LEFT_ARROW);

	}
	if (key == 'A') {
		if (ConTank)
		{
			ConTank->Order = ATTACK_BASE;
			ConTank->OrderTarget = &Player2.Build;
			ConTank->Status = 1;
		}
	}
	if (key == 27)exit(1);
	if (key == 'P') {
		if (ConTank)
		{
			ConTank->Order = PROTECT_HELICOPTER;
		}

	}
	if (key == 'p') {
		if (ConTank)
		{
			ConTank->Order = ATTACK_HELICOPTER;
		}

	}
	if (key == 'O')
	{
		if (ConTank)
		{
			ConTank->Order = PROTECT_BASE;
			ConTank->GetPath(&ground, Player1.Build.Location.x / 2, Player1.Build.Location.z / 2 - 1);
		}
	}
	if (key == 'f')Heli->Fire();
	if (key == 'c')Heli->Up -= 5;
	if (key == ' ')Heli->Up += 5;
	if (key == 'm') {
		mode = !mode;
		if (mode == 1)
			Arrow.Location.Set_(Player1.Heli.Location.x, 0, Player1.Heli.Location.z);
		Heli->Rotation.x = Heli->Rotation.z = 0;
	}
	if (key == 'q')
	{
		Heli->Rotation.y += 5;
		if (Heli->Rotation.y == 185)Heli->Rotation.y = -175;
	}
	if (key == 'e')
	{
		Heli->Rotation.y -= 5;
		if (Heli->Rotation.y == -185)Heli->Rotation.y = 175;
	}

	Player2.BotBuyIndex = 0;
	if (key == '1') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = EASY_BOT;
		Player2.Plan = DEFEND_PLAN;
	}
	if (key == '2') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = EASY_BOT;
		Player2.Plan = MID_PLAN;
	}
	if (key == '3') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = EASY_BOT;
		Player2.Plan = ATTACK_PLAN;
	}
	if (key == '4') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = MID_BOT;
		Player2.Plan = DEFEND_PLAN;
	}
	if (key == '5') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = MID_BOT;
		Player2.Plan = MID_PLAN;
	}
	if (key == '6') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = MID_BOT;
		Player2.Plan = ATTACK_PLAN;
	}
	if (key == '7') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = HARD_BOT;
		Player2.Plan = DEFEND_PLAN;
	}
	if (key == '8') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = HARD_BOT;
		Player2.Plan = MID_PLAN;
	}
	if (key == '9') {
		for (int i = 0; i < 10; i++)
			Player2.TanksIn[i] = 0;
		Player2.Difficult = HARD_BOT;
		Player2.Plan = ATTACK_PLAN;
	}

	glutPostRedisplay();
}

void DrawSun()
{
	glDisable(GL_FOG);
	b[0] = 30 + sin(SunDegree) * 150;
	b[1] = -100 + cos(SunDegree) * 150;
	b[2] = 50;
	glTranslatef(b[0], b[1], b[2]);
	glColor3f(10, 8, 0);
	glutSolidSphere(15, 20, 20);
	glTranslatef(-b[0], -b[1], -b[2]);
	glDisable(GL_LIGHT1);
	SpaceShip.Draw();
	if (b[1] > 0)
		glClearColor(b[1]*0.002, b[1]*0.006, b[1] * 0.05, 0.0);
	if (b[1] > 0 && b[0] > 60)density += 0.00005;
	if (b[1] > 0 && b[0] < 10)density -= 0.00005;
	glFogf(GL_FOG_DENSITY, density); //set the density to the

	glColor3f(10, 10, 10);
	for(int i=0;i< STARS_COUNT;i++)
		stars[i].Draw();

	{
		b[0] = 30 + sin(SunDegree + 180) * 120;
		b[1] = 30;
		b[2] = 50 + cos(SunDegree + 180) * 120;
		glTranslatef(b[0], b[1], b[2]);
		glRotatef(35, 1, 0, 1);
		glColor3f(10, 0, 8);
		glutSolidSphere(10, 20, 20);
		glColor3f(10, 5, 2);
		glScalef(10, 1, 10);
		glutSolidSphere(1.5, 20, 20);
		glScalef(0.1, 1, 0.1);
		glRotatef(-35, 1, 0, 1);
		glTranslatef(-b[0], -b[1], -b[2]);
	}
	{
		b[0] = 30 + sin(SunDegree ) * 120;
		b[1] = 30;
		b[2] = 50 + cos(SunDegree ) * 120;
		glTranslatef(b[0], b[1], b[2]);
		glColor3f(2, 5, 10);
		glutSolidSphere(10, 20, 20);
		glTranslatef(-b[0], -b[1], -b[2]);
	}
	{
		b[0] = 30 + sin(SunDegree * 2) * 140;
		b[1] = 40;
		b[2] = 50 + cos(SunDegree * 2) * 140;
		glTranslatef(b[0], b[1], b[2]);
		glColor3f(2, 10, 3);
		glutSolidSphere(10, 20, 20);
		glTranslatef(-b[0], -b[1], -b[2]);
	}
	
	glLightfv(GL_LIGHT1, GL_POSITION, b);
	glEnable(GL_LIGHT1);
	glEnable(GL_FOG);
	

}
void Draw_Game()
{

	for (int i = 0; i < 198; i++)Around[i].Draw();
	Player1.Draw();
	Player2.Draw();
	for (int i = 0; i < 50; i++)Coins[i].Draw();
	for (int i = 0; i < 10; i++)Repairs[i].Draw();
	for (int i = 0; i < 10; i++)
	{
		if (Player1.TanksIn[i])
		{
			PrintStringAt(Player1.Tanks[i].Location.x,
				Player1.Tanks[i].Location.y + 1,
				Player1.Tanks[i].Location.z, 1, 0, 0, to_string(i).c_str());
		}
	}
	ground.Draw();
	for (int i = 0; i < BuildsCount; i++)
		MapBuildings[i].Draw();
	if (mode) {
		glTranslatef(Arrow.Location.x, 0, Arrow.Location.z);
		Arrow.box[0].Draw();
		glTranslatef(-Arrow.Location.x, 0, -Arrow.Location.z);

		if (CollectingFlag)
		{
			glColor3f(5,0,0);
			glBegin(GL_LINE_LOOP);
			glVertex3f(From.x,1, From.z);
			glVertex3f(From.x,1,Arrow.Location.z);
			glVertex3f(Arrow.Location.x,1, Arrow.Location.z);
			glVertex3f(Arrow.Location.x, 1,From.z);
			glEnd();
		}
		else
		{
			for (int i = 0; i < 10; i++)
				if (CollectedTanks[i] == 1)
				{
					glColor3f(0, 0, 10);
					Player1.Tanks[i].Go_Location();
					glutWireSphere(1,4,4);
					Player1.Tanks[i].Back_Location();

				}
		}
		if (ConTank) {
			ConTank->Go_Location();
			glutWireCube(2);
			ConTank->Back_Location();
		}
	}
	for (int k = 0; k < BUILDBOX_COUNT; k++)
		if (!BuildBoxes[k].Status)BuildBoxes[k].Draw();


	Station[0].Draw();
	Station[1].Draw();
	Station[2].Draw();
	
	DrawSun();
	DrawLights();

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(1, 1, 1, 0.2);
	Arrow.Go_Location();
	glutSolidCube(1);
	Arrow.Back_Location();
	glDisable(GL_BLEND);
}
void Draw_Shop()
{
	ShopTankMenu[0].Draw_Button();
	ShopTankMenu[1].Draw_Button();
	ShopTankMenu[2].Draw_Button();
	ShopTankMenu[3].Draw_Button();
	ShopTankMenuBack.Draw_Button();
	for (int i = 0; i < 4; i++)
		ShowTank[i].Draw();
	for (int i = 0; i < 6; i++)
		ShopTankOrder[i].Draw_Button();
	{
		PrintStringAt(-4.6, 0.3, -5, 1, 1, 1, "Anti Tanks");
		PrintStringAt(-4.6, 0.1, -5, 1, 1, 1, "Shoots : High Shells");
		PrintStringAt(-4.6, -0.1, -5, 1, 1, 1, "Price  : 100");
		PrintStringAt(-4.6, -0.3, -5, 1, 1, 1, "Damage : 50");
		PrintStringAt(-4.6, -0.5, -5, 1, 1, 1, "Range  : 10");

		PrintStringAt(-1.8, 0.3, -5, 1, 1, 1, "Anti Helicopters");
		PrintStringAt(-1.8, 0.1, -5, 1, 1, 1, "Shoots : High Bullets");
		PrintStringAt(-1.8, -0.1, -5, 1, 1, 1, "Price  : 150");
		PrintStringAt(-1.8, -0.3, -5, 1, 1, 1, "Damage : 30");
		PrintStringAt(-1.8, -0.5, -5, 1, 1, 1, "Range  : 15");

		PrintStringAt(1, 0.3, -5, 1, 1, 1, "Anti Helicopters");
		PrintStringAt(1, 0.1, -5, 1, 1, 1, "Shoots : Missiles");
		PrintStringAt(1, -0.1, -5, 1, 1, 1, "Price  : 200");
		PrintStringAt(1, -0.3, -5, 1, 1, 1, "Damage : 50");
		PrintStringAt(1, -0.5, -5, 1, 1, 1, "Range  : 25");

		PrintStringAt(3.3, 0.3, -5, 1, 1, 1, "Anti Tanks/Buildings");
		PrintStringAt(3.3, 0.1, -5, 1, 1, 1, "Shoots : Missiles");
		PrintStringAt(3.3, -0.1, -5, 1, 1, 1, "Price  : 200");
		PrintStringAt(3.3, -0.3, -5, 1, 1, 1, "Damage : 50");
		PrintStringAt(3.3, -0.5, -5, 1, 1, 1, "Range  : 50");
	}

	glTranslatef(0, -2, -8);
	glRotatef(Heli->Rotation.x, 1, 0, 0);
	glRotatef(Heli->Rotation.z, 0, 0, 1);
	glRotatef(-Heli->Rotation.y - 180, 0, 1, 0);
	Heli->Back_Location();
	glViewport(950, 550, 600, 400);
	Draw_Game();
	glViewport(0, 0, WIDTH, HEIGHT);

}
void Draw_Info()
{
	{
		PrintStringAt(-5.0, -2.4, -5, 1, 1, 0, "Conis  : ");
		PrintStringAt(-4.5, -2.4, -5, 1, 1, 0, to_string(Player1.Coins).c_str());
		PrintStringAt(-5.0, -2.6, -5, 1, 1, 0, "Health : ");
		PrintStringAt(-4.5, -2.6, -5, 1, 1, 0, to_string(Player1.Heli.Health).c_str());
		PrintStringAt(-5.0, -2.8, -5, 1, 1, 0, "S : ");
		PrintStringAt(-4.5, -2.8, -5, 1, 1, 0, to_string(Player2.Heli.Status).c_str());
		PrintStringAt(-4.3, -2.8, -5, 1, 0, 0, to_string(Player2.Heli.GetBuildBox==NULL).c_str());
	}

	PrintStringAt(-4.3, 2.5, -5, 0, 1, 0, TankOrder(&Player1.Tanks[0]));
	PrintStringAt(-4.3, 2.0, -5, 0, 1, 0, TankOrder(&Player1.Tanks[1]));
	PrintStringAt(-4.3, 1.5, -5, 0, 1, 0, TankOrder(&Player1.Tanks[2]));
	PrintStringAt(-4.3, 1.0, -5, 0, 1, 0, TankOrder(&Player1.Tanks[3]));
	PrintStringAt(-4.3, 0.5, -5, 0, 1, 0, TankOrder(&Player1.Tanks[4]));
	PrintStringAt(-4.3, 0.0, -5, 0, 1, 0, TankOrder(&Player1.Tanks[5]));
	PrintStringAt(-4.3, -0.5, -5, 0, 1, 0, TankOrder(&Player1.Tanks[6]));
	PrintStringAt(-4.3, -1.0, -5, 0, 1, 0, TankOrder(&Player1.Tanks[7]));
	PrintStringAt(-4.3, -1.5, -5, 0, 1, 0, TankOrder(&Player1.Tanks[8]));
	PrintStringAt(-4.3, -2.0, -5, 0, 1, 0, TankOrder(&Player1.Tanks[9]));

	PrintStringAt(-5, 2.5, -5, 1, 1, 1, "Tank-0 :");
	PrintStringAt(-5, 2.0, -5, 1, 1, 1, "Tank-1 :");
	PrintStringAt(-5, 1.5, -5, 1, 1, 1, "Tank-2 :");
	PrintStringAt(-5, 1.0, -5, 1, 1, 1, "Tank-3 :");
	PrintStringAt(-5, 0.5, -5, 1, 1, 1, "Tank-4 :");
	PrintStringAt(-5, 0.0, -5, 1, 1, 1, "Tank-5 :");
	PrintStringAt(-5, -0.5, -5, 1, 1, 1, "Tank-6 :");
	PrintStringAt(-5, -1.0, -5, 1, 1, 1, "Tank-7 :");
	PrintStringAt(-5, -1.5, -5, 1, 1, 1, "Tank-8 :");
	PrintStringAt(-5, -2.0, -5, 1, 1, 1, "Tank-9 :");

	for (int i = 0; i < 10; i++)
		if (Player1.TanksIn[i] == 1)
		{
			switch (Player1.Tanks[i].Type)
			{
			case 1:
				PrintStringAt(-5, 2.3 - i * 0.5, -5, 1, 0, 0, "Shell Tank");
				break;
			case 2:
				PrintStringAt(-5, 2.3 - i * 0.5, -5, 1, 0, 0, "Bullets Tank");
				break;
			case 3:
				PrintStringAt(-5, 2.3 - i * 0.5, -5, 1, 0, 0, "Missiles Tank");
				break;
			case 4:
				PrintStringAt(-5, 2.3 - i * 0.5, -5, 1, 0, 0, "Heavy Tank");
				break;
			}
		}
		else
			PrintStringAt(-5, 2.3 - i * 0.5, -5, 1, 0, 0, "------");
}
void MainManu()
{
	PrintStringAt(3.0, 2.5, -5, 10, 10, 10, "Choose Map");
	Maps[0].Draw_Button();
	Maps[1].Draw_Button();
	Maps[2].Draw_Button();
	Maps[3].Draw_Button();
	Maps[4].Draw_Button();
	Maps[5].Draw_Button();

	LevelBtns[0].Draw_Button();
	LevelBtns[1].Draw_Button();
	LevelBtns[2].Draw_Button();

	Diffecult[0].Draw_Button();
	Diffecult[1].Draw_Button();
	Diffecult[2].Draw_Button();

	LevelShows[0].Draw();
	LevelShows[1].Draw();
	LevelShows[2].Draw();

	if (Player2.DifficultSpeed == 500) {
		PrintStringAt(2.5, 0, -5, 10, 10, 10, "--->");
		PrintStringAt(3.0, -1.5, -5, 10, 10, 10, "Good for traing");
		PrintStringAt(3.0, -1.7, -5, 10, 10, 10, "Enemy creates tanks slowly");
	}
	if (Player2.DifficultSpeed == 250) {
		PrintStringAt(2.5, -0.5, -5, 10, 10, 0, "--->");
		PrintStringAt(3.0, -1.5, -5, 10, 10, 0, "You are getting better");
	}
	if (Player2.DifficultSpeed == 100) {
		PrintStringAt(2.5, -1.0, -5, 10, 0, 0, "--->");
		PrintStringAt(3.0, -1.5, -5, 10, 0, 0, "You wont win");
		PrintStringAt(3.0, -1.7, -5, 10, 0, 0, "Enemy creates tanks fast");

	}
	
	if (LevelChoosen == 3)PrintStringAt(-0.5, -2, -5, 10, 0, 0, "--->");
	if (LevelChoosen == 2)PrintStringAt(-2.5, -2, -5, 10, 10, 0, "--->");
	if (LevelChoosen == 1)PrintStringAt(-4.5, -2, -5, 10, 10, 10, "--->");

	PrintStringAt(-4, -0, -5, 10, 10, 0, "----------------------------------------------");
	PrintStringAt(-2.5, -0.2, -5, 10, 10, 0, "Choose level");
	PrintStringAt(-4, -0.4, -5, 10, 10, 0, "----------------------------------------------");

}
void draw()
{
	glClear(GL_COLOR_BUFFER_BIT |
		GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	if (Page != PLAYING)
	{
		MainManu();
	}
	if (Page == PLAYING)
	{
		if (!Shopping)
		{
			if (!mode) {
				//Draw_Info();

				{
					glTranslatef(HeiMoveCamera.x, HeiMoveCamera.y, 0);
					glRotatef(90, 1, 0, 0);
					glRotatef(-Heli->Rotation.y - 180, 0, 1, 0);
					Heli->Back_Location();
					glViewport(0, 0, 200, 200);
					gluPerspective(90, 0, 0, 300);
					glTranslatef(0, -3, 0);
					Draw_Game();
					glTranslatef(0, 3, 0);
					gluPerspective(60, 0, 0, 300);
					Heli->Go_Location();
					glRotatef(Heli->Rotation.y + 180, 0, 1, 0);
					glRotatef(-90, 1, 0, 0);
					glTranslatef(-HeiMoveCamera.x, -HeiMoveCamera.y, 0);
					glViewport(0, 0, WIDTH, HEIGHT);

				}
				{
					if (InSide)
					{
						glTranslatef(HeiMoveCamera.x, HeiMoveCamera.y, 0);
						glEnable(GL_LIGHT7);
						glBegin(GL_LINES);
						glColor3f(0, 0, 10);
						glVertex3f(-0.1, Heli->Rotation.x / 250, -1.5);
						glVertex3f(0, Heli->Rotation.x / 250, -1.5);


						glVertex3f( -Heli->Rotation.z / 250,-0.1, -1.5);
						glVertex3f( -Heli->Rotation.z / 250,0, -1.5);
						glColor3f(10, 0, 0);
						glVertex3f(0.39, 0, -1.5);
						glVertex3f(0, 0, -1.5);

						glVertex3f(0.39, 0.15, -1.5);
						glVertex3f(0.39, -0.05, -1.5);

						glVertex3f(0.18, 0.01, -1.5);
						glVertex3f(0.18, -0.02, -1.5);

						glVertex3f(0.22, 0.01, -1.5);
						glVertex3f(0.22, -0.02, -1.5);

						glVertex3f(1.0, 0.6, -1.5);
						glVertex3f(1.5, 1.1, -1.5);

						glVertex3f(1.0, -0.6, -1.5);
						glVertex3f(1.5, -1.1, -1.5);

						glVertex3f(-0.6, -0.6, -1.5);
						glVertex3f(-1.1, -1.1, -1.5);

						glVertex3f(-0.6, 0.6, -1.5);
						glVertex3f(-1.1, 1.1, -1.5);
						glEnd();
						glBegin(GL_LINE_LOOP);
						glVertex3f(1.0, 0.6, -1.5);
						glVertex3f(1.0, -0.6, -1.5);
						glVertex3f(-0.6, -0.6, -1.5);
						glVertex3f(-0.6, 0.6, -1.5);
						glEnd();
						PrintStringAt(0.4, 0.02, -1.5, 10, 10, 10, "Holding : ");
						if (Player1.Heli.BB != NULL) PrintStringAt(0.6, 0.02, -1.5, 0, 0, 10, "YES");
						else PrintStringAt(0.6, 0.02, -1.5, 10, 0, 0, "NO");

						PrintStringAt(0.4, 0.06, -1.5, 10, 10, 10, "Health : ");
						PrintStringAt(0.6, 0.06, -1.5, 0, 0, 10, to_string(Player1.Heli.Health).c_str());

						PrintStringAt(0.4, 0.1, -1.5, 10, 10, 10, "Coins  : ");
						PrintStringAt(0.6, 0.1, -1.5, 0, 0, 10, to_string(Player1.Coins).c_str());

						PrintStringAt(0.4, -0.08, -1.5, 10, 10, 10, "Height  : ");
						PrintStringAt(0.6, -0.08, -1.5, 0, 0, 10, to_string(Player1.Heli.Location.y).c_str());


						PrintStringAt(0.4, -0.03, -1.5, 10, 10, 10, "Stading  : ");
						if (Player1.Heli.AirStop)PrintStringAt(0.6, -0.03, -1.5, 0, 0, 10, "ON");
						else PrintStringAt(0.6, -0.03, -1.5, 10, 0, 0, "OFF");
						glDisable(GL_LIGHT7);
					}
					else
						glTranslatef(HeiMoveCamera.x, HeiMoveCamera.y,+1);
					//glRotatef(Heli->Rotation.x, 1, 0, 0);
					//glRotatef(Heli->Rotation.z, 0, 0, 1);
					glRotatef(-Heli->Rotation.y - 180, 0, 1, 0);
					Heli->Back_Location();
				}
				
			}
			else
			{
				glTranslatef(-(Arrow.Location.x+ax), (Arrow.Location.z+az), -40);
				glRotatef(80, 1, 0, 0);
			}
			glViewport(200, 0, WIDTH - 200, HEIGHT);
			Draw_Game();
			glViewport(0, 0, WIDTH, HEIGHT);
		}
		else
		{
			Draw_Shop();
		}
	}
	glutSwapBuffers();			// display the output
}

void BuildBounds(Player* PL)
{
	for (int i = 0; i < BuildsCount; i++)
	{
		for(int j=0;j< BUILDBOX_COUNT;j++)
			if (Obj_Bound(&MapBuildings[i], &BuildBoxes[j], &MapBuildings[i].Location, &BuildBoxes[j].Location))
				BuildBoxes[j].BOUNDED = 1;
		for (int j = 0; j < 50; j++)
			if (Obj_Bound(&MapBuildings[i], &Coins[j], &MapBuildings[i].Location, &Coins[j].Location))
				Coins[j].Status = 0;
		for (int j = 0; j < 10; j++)
			if (Obj_Bound(&MapBuildings[i], &Repairs[j], &MapBuildings[i].Location, &Repairs[j].Location))
				Repairs[j].Status = 0;

		for (int j = 0; j < 10; j++)
			if (PL->Heli.bullet[j].Status && Obj_Bound(&PL->Heli.bullet[j], &MapBuildings[i], &PL->Heli.bullet[j].Location, &MapBuildings[i].Location))
			{
				PL->Heli.bullet[j].Location.x -= PL->Heli.bullet[j].Speed.x;
				PL->Heli.bullet[j].Location.y -= PL->Heli.bullet[j].Speed.y;
				PL->Heli.bullet[j].Location.z -= PL->Heli.bullet[j].Speed.z;
				PL->Heli.bullet[j].BlowFunc();
				PL->Heli.bullet[j].Location.Set_(0, 100, 0);
				MapBuildings[i].Health -= PL->Heli.bullet[j].Damage;

			}
		for (int j = 0; j < TANKS_COUNT; j++)
		{
			switch (PL->Tanks[j].Type)
			{
			case 1:
				if (Obj_Bound(&PL->Tanks[j].bullet[0], &MapBuildings[i], &PL->Tanks[j].bullet[0].Location, &MapBuildings[i].Location))
				{
					PL->Tanks[j].bullet[0].BlowFunc();
					PL->Tanks[j].bullet[0].Location.Set_(0, 100, 0);
					MapBuildings[i].Health -= PL->Tanks[j].bullet[0].Damage;
				}
				break;
			case 2:
				for (int k = 0; k < 5; k++)
					if (Obj_Bound(&PL->Tanks[j].bullet[k], &MapBuildings[i], &PL->Tanks[j].bullet[k].Location, &MapBuildings[i].Location))
					{
						PL->Tanks[j].bullet[k].Location.x -= PL->Tanks[j].bullet[k].Speed.x;
						PL->Tanks[j].bullet[k].Location.y -= PL->Tanks[j].bullet[k].Speed.y;
						PL->Tanks[j].bullet[k].Location.z -= PL->Tanks[j].bullet[k].Speed.z;
						PL->Tanks[j].bullet[k].BlowFunc();
						PL->Tanks[j].bullet[k].Location.Set_(0, 100, 0);
						MapBuildings[i].Health -= PL->Tanks[j].bullet[k].Damage;

					}
				break;
			case 3:
				if (Obj_Bound(&PL->Tanks[j].cannon.missile_1, &MapBuildings[i], &PL->Tanks[j].cannon.missile_1.Location, &MapBuildings[i].Location))
				{
					PL->Tanks[j].cannon.missile_1.BlowFunc();
					MapBuildings[i].Health -= PL->Tanks[j].cannon.missile_1.Damage;
				}
				if (Obj_Bound(&PL->Tanks[j].cannon.missile_2, &MapBuildings[i], &PL->Tanks[j].cannon.missile_2.Location, &MapBuildings[i].Location))
				{
					PL->Tanks[j].cannon.missile_2.BlowFunc();
					MapBuildings[i].Health -= PL->Tanks[j].cannon.missile_2.Damage;
				}
				break;
			case 4:
				if (Obj_Bound(&PL->Tanks[j].missile, &MapBuildings[i], &PL->Tanks[j].missile.Location, &MapBuildings[i].Location))
				{
					PL->Tanks[j].missile.BlowFunc();
					MapBuildings[i].Health -= PL->Tanks[j].missile.Damage;
				}
				break;
			}
		}

	}
}
void HeliBounds(Player* PL1, Player* PL2)
{
	for (int i = 0; i < 50; i++)
	{
		if (Obj_Bound(&PL1->Heli, &Coins[i], &PL1->Heli.Location, &Coins[i].Location))
		{
			Coins[i].Status = 1;
			Coins[i].Location.y = 100;
			PL1->Coins += 15;
		}
	}
	for (int i = 0; i < 10; i++)
	{
		if (PL1->Heli.Health < 100 && Obj_Bound(&PL1->Heli, &Repairs[i], &PL1->Heli.Location, &Repairs[i].Location))
		{
			Repairs[i].Status = 1;
			Repairs[i].Location.y = 100;
			PL1->Heli.Health += 30;
			if (PL1->Heli.Health > 100)
				PL1->Heli.Health = 100;
		}
	}
	for (int i = 0; i < TANKS_COUNT; i++)
	{
		for (int k = 0; k < 10; k++)
			if (PL2->TanksIn[i]&& PL1->Heli.bullet[k].Status&&Distance(&PL1->Heli.bullet[k], &PL2->Tanks[i]) < 1)
			{
				PL2->Tanks[i].Health -= 50;
				if (PL2->Tanks[i].Health <= 0)
				{
					PL2->TanksIn[i] = 0;
					PL2->Tanks[i].Destroy(); 
					PL1->Heli.bullet[k].BlowFunc();
					PL1->Heli.bullet[k].Location.Set_(0, 100, 0);
				}
			}
		if (PL1->Tanks[i].Type == 2)
		{
			if (!PL1->Tanks[i].Target && Distance(&PL1->Tanks[i], &PL2->Heli) < 15)
				PL1->Tanks[i].Target = &PL2->Heli;
			if (PL1->Tanks[i].Target == &PL2->Heli && Distance(&PL1->Tanks[i], &PL2->Heli) >= 15)
				PL1->Tanks[i].Target = NULL;
		}
		if (PL1->Tanks[i].Type == 3)
		{
			if (!PL1->Tanks[i].Target && Distance(&PL1->Tanks[i], &PL2->Heli) < 25)
				PL1->Tanks[i].Target = &PL2->Heli;
			if (PL1->Tanks[i].Target == &PL2->Heli && Distance(&PL1->Tanks[i], &PL2->Heli) >= 25)
				PL1->Tanks[i].Target = NULL;
		}
		switch (PL2->Tanks[i].Type)
		{
		case 2:
			for (int k = 0; k < 5; k++)
				if (Distance(&PL2->Tanks[i].bullet[k], &PL1->Heli)<1)
				{
					PL2->Tanks[i].bullet[k].Location.x -= PL2->Tanks[i].bullet[k].Speed.x;
					PL2->Tanks[i].bullet[k].Location.y -= PL2->Tanks[i].bullet[k].Speed.y;
					PL2->Tanks[i].bullet[k].Location.z -= PL2->Tanks[i].bullet[k].Speed.z;
					PL2->Tanks[i].bullet[k].BlowFunc();
					PL2->Tanks[i].bullet[k].Location.Set_(0, 100, 0);
					PL1->Heli.Health -= PL2->Tanks[i].bullet[k].Damage;
					if (PL1->Heli.Health <= 0)
						PL1->Heli.Destroy();
				}
			break;
		case 3:
			if (Obj_Bound(&PL2->Tanks[i].cannon.missile_1, &PL1->Heli, &PL2->Tanks[i].cannon.missile_1.Location, &PL1->Heli.Location))
			{
				PL1->Heli.speed.x += PL2->Tanks[i].cannon.missile_1.Speed.x;
				PL1->Heli.speed.y += PL2->Tanks[i].cannon.missile_1.Speed.y;
				PL1->Heli.speed.z += PL2->Tanks[i].cannon.missile_1.Speed.z;
				PL1->Heli.Health -= PL2->Tanks[i].cannon.missile_2.Damage;
				PL2->Tanks[i].cannon.missile_1.BlowFunc();
				if (PL1->Heli.Health <= 0)
					PL1->Heli.Destroy();
			}
			if (Obj_Bound(&PL2->Tanks[i].cannon.missile_2, &PL1->Heli, &PL2->Tanks[i].cannon.missile_2.Location, &PL1->Heli.Location))
			{
				PL1->Heli.speed.x += PL2->Tanks[i].cannon.missile_2.Speed.x;
				PL1->Heli.speed.y += PL2->Tanks[i].cannon.missile_2.Speed.y;
				PL1->Heli.speed.z += PL2->Tanks[i].cannon.missile_2.Speed.z;
				PL1->Heli.Health -= PL2->Tanks[i].cannon.missile_2.Damage;
				PL2->Tanks[i].cannon.missile_2.BlowFunc();
				if (PL1->Heli.Health <= 0)
					PL1->Heli.Destroy();
			}
			break;
		case 4:
			if (Obj_Bound(&PL2->Tanks[i].missile, &MapBuildings[i], &PL2->Tanks[i].missile.Location, &PL1->Heli.Location))
			{
				PL1->Heli.Destroy();
				PL2->Tanks[i].missile.BlowFunc();
			}
			break;
		}
	}
}
void TankBounds(Player* PL1, Player* PL2)
{
	for (int j = 0; j < TANKS_COUNT; j++)
	{
		for (int i = 0; i < TANKS_COUNT; i++)
		{
			if (PL1->Tanks[j].Target == &PL2->Tanks[i])
				if (PL2->Tanks[i].Health <= 0)
				{
					PL2->TanksIn[i] = 0;
					PL2->Tanks[i].Order = IDLE_TANK;
					PL2->Tanks[i].ProtectBy = PL2->Tanks[i].ProtectBy = NULL;
					PL1->Tanks[j].Target = PL1->Tanks[j].OrderTarget = NULL;
					if (ConTank == &PL2->Tanks[i])ConTank = NULL;
				}
			if (!PL1->TanksIn[j] || !PL2->TanksIn[i])continue;

			if (PL1->Tanks[j].Type == 1 && PL1->Tanks[j].Order == PROTECT_BASE && PL2->Tanks[i].Target == &PL1->Build)
			{
				PL1->Tanks[j].OrderTarget = &PL2->Tanks[i];
				return;
			}

			switch (PL1->Tanks[j].Type)
			{
			case 1:
				if (Distance(&PL1->Tanks[j], &PL2->Tanks[i]) < PL1->Tanks[j].Range)
				{
					if (PL1->Tanks[j].Order == IDLE_TANK || PL1->Tanks[j].Order == PROTECT_TANK && !PL1->Tanks[j].Target)
						PL1->Tanks[j].Target = &PL2->Tanks[i];
					if (PL1->Tanks[j].Order == PROTECT_BASE)
						PL1->Tanks[j].OrderTarget = &PL2->Tanks[i];
				}
				if (Distance(&PL1->Tanks[j].bullet[0], &PL2->Tanks[i])<1)
				{
					PL1->Tanks[j].bullet[0].BlowFunc();
					PL1->Tanks[j].bullet[0].Location.Set_(0, 100, 0);
					PL2->Tanks[i].Health -= PL1->Tanks[j].bullet[0].Damage;

				}
				if (PL2->Tanks[i].Health <= 0)
				{
					PL2->TanksIn[i] = 0;
					PL2->Tanks[i].Destroy();
					PL1->Tanks[j].Target = PL1->Tanks[j].OrderTarget = NULL;
					if (ConTank == &PL2->Tanks[i])ConTank = NULL;
				}
				
				break;
			case 2:
				if (PL2->Tanks[i].Type == 4)
				{
					if (&PL2->Tanks[i].missile.Status && !PL1->Tanks[j].Target &&Distance(&PL1->Tanks[j], &PL2->Tanks[i].missile)< PL1->Tanks[j].Range)
						PL1->Tanks[j].Target = &PL2->Tanks[i].missile;
					
				}
				for (int k = 0; k < 5; k++)
				{
					if (PL2->Tanks[i].Type == 4)
						if (Distance(&PL1->Tanks[j].bullet[k], &PL2->Tanks[i].missile)<1)
						{
							PL2->Tanks[i].missile.BlowFunc();
							PL1->Tanks[j].bullet[k].BlowFunc();
							PL1->Tanks[j].bullet[k].Location.Set_(0, 100, 0);

						}
					
					if (Obj_Bound(&PL1->Tanks[j].bullet[k], &PL2->Tanks[i], &PL1->Tanks[j].bullet[k].Location, &PL2->Tanks[i].Location) ||
						Obj_Bound(&PL1->Tanks[j].bullet[k], &PL2->Tanks[i].cannon, &PL1->Tanks[j].bullet[k].Location, &PL2->Tanks[i].Location))
					{
						PL1->Tanks[j].bullet[k].Location.x -= PL1->Tanks[j].bullet[k].Speed.x;
						PL1->Tanks[j].bullet[k].Location.y -= PL1->Tanks[j].bullet[k].Speed.y;
						PL1->Tanks[j].bullet[k].Location.z -= PL1->Tanks[j].bullet[k].Speed.z;
						PL1->Tanks[j].bullet[k].BlowFunc();
						PL1->Tanks[j].bullet[k].Location.Set_(0, 100, 0);

					}

				}
				break;
			case 3:
				if (Obj_Bound(&PL1->Tanks[j].cannon.missile_1, &PL2->Tanks[i], &PL1->Tanks[j].cannon.missile_1.Location, &PL2->Tanks[i].Location) ||
					Obj_Bound(&PL1->Tanks[j].cannon.missile_1, &PL2->Tanks[i].cannon, &PL1->Tanks[j].cannon.missile_1.Location, &PL2->Tanks[i].Location))
					PL1->Tanks[j].cannon.missile_1.BlowFunc();
				if (Obj_Bound(&PL1->Tanks[j].cannon.missile_2, &PL2->Tanks[i], &PL1->Tanks[j].cannon.missile_2.Location, &PL2->Tanks[i].Location))
					PL1->Tanks[j].cannon.missile_2.BlowFunc();
				break;
			case 4:
				if (Distance(&PL1->Tanks[j].missile, &PL2->Tanks[i]) < 1 && PL1->Tanks[j].missile.Location.y<0.5)
				{
					PL1->Tanks[j].missile.BlowFunc();
					PL2->Tanks[i].Health -= PL1->Tanks[j].missile.Damage;
					if (PL2->Tanks[i].Health <= 0)
					{
						PL2->TanksIn[i] = 0;
						PL2->Tanks[i].Order = IDLE_TANK;
						PL2->Tanks[i].ProtectBy = PL2->Tanks[i].ProtectBy = NULL;
						PL1->Tanks[j].Target = PL1->Tanks[j].OrderTarget = NULL;
						if (ConTank == &PL2->Tanks[i])ConTank = NULL;

					}
				}
				break;
			}
		}

	}
}
void BuildBoxBounds(Player* PL)
{
	int k, j,r;
	for (k = 0; k < BUILDBOX_COUNT; k++)
	{
		j = testObj_Bound(&BuildBoxes[k], &PL->Build, &BuildBoxes[k].Location, &PL->Build.Location);
		if (j && (j == 1 || j == 2 || j == 3 || j == 4) || (PL->Build.BoxIn[j - 4] == 1))
		{
			PL->Heli.GetBuildBox = NULL;
			PL->Build.BoxIn[j] = 1;

			BuildBoxes[k].RandBox();

			PL->Count++;
			ChoosePlan(Player1.Need(), Player2.Need());
			return;
		}
	}
}
void HeliBuildBounds(Player* PL)
{
	for (int i = 0; i < BuildsCount; i++)
	{
		for (int j = 0; j < MapBuildings[i].Box_Count; j++)
			switch (Bound_Status(PL->Heli.body, &PL->Heli.Location, MapBuildings[i].box[j], &MapBuildings[i].Location))
			{
			case LEFT_BOUND:
				PL->Heli.speed.x *= -1;
				PL->Heli.Rotation.z *= -1;
				PL->Heli.Rotation.z /= 2;
				PL->Heli.Location.x += 0.1;
				break;
			case RIGHT_BOUND:
				PL->Heli.speed.x *= -1;
				PL->Heli.Rotation.z *= -1;
				PL->Heli.Rotation.z /= 2;
				PL->Heli.Location.x -= 0.1;
				break;
			case UP_BOUND:
				PL->Heli.Location.y -= 0.1;
				PL->Heli.Up = 20;
				break;
			case DAWN_BOUND:
				PL->Heli.Location.y += 0.1;
				PL->Heli.Up = 20;
				break;
			case FRONT_BOUND:
				PL->Heli.speed.z *= -1;
				PL->Heli.Rotation.x *= -1;
				PL->Heli.Rotation.x /= 2;
				PL->Heli.Location.z -= 0.1;
				break;
			case BACK_BOUND:
				PL->Heli.speed.z *= -1;
				PL->Heli.Rotation.x *= -1;
				PL->Heli.Rotation.x /= 2;
				PL->Heli.Location.z += 0.1;
				break;
			}

	}
}
void BuildBoxHeliBounds(Player* PL)
{
	for (int k = 0; k < BUILDBOX_COUNT; k++)
		if (BuildBoxes[k].BOUNDED && Obj_Bound(&PL->Heli, &BuildBoxes[k], &PL->Heli.Location, &BuildBoxes[k].Location) && !BuildBoxes[k].Status && PL->Heli.BB == NULL)
		{
			PL->Heli.Status = 3;
			BuildBoxes[k].ReRand = 0;
			BuildBoxes[k].box[0].Location.Set_(0, 0, 0);
			BuildBoxes[k].Location.Set_(0, -0.5, 0);
			PL->Heli.BB = &BuildBoxes[k];
			BuildBoxes[k].Status = 1;
		}
}

void BaseBuildBound(Player* PL1, Player* PL2)
{
	for (int i = 0; i < TANKS_COUNT; i++)
		if (PL1->Tanks[i].Type==4)
			if (Obj_Bound(&PL1->Tanks[i].missile, &PL2->Build, &PL1->Tanks[i].missile.Location, &PL2->Build.Location))
			{
				PL1->Tanks[i].missile.BlowFunc();
				for (int j = 16; j > 0; j--)
				{
					if (PL2->Build.BoxIn[j] == 1)
					{
						PL2->Build.BoxIn[j] = 0;
						PL2->Count--;
						break;
					}
				}
			}
}

void idle()
{
	if (Shopping)
	{
		for (int i = 0; i < 4; i++) {
			ShowTank[i].Rotation.y = ((int)ShowTank[i].Rotation.y + 2) % 360;
			ShowTank[i].Move(&Distance,&SendTank,&ground);
		}
		draw();
		return;
	}
	for (int i = 0; i < 50; i++) {
		Coins[i].Rotation.y = ((int)Coins[i].Rotation.y + 2) % 360;
		if (Coins[i].Status)Coins[i].Location.y -= 0.1;
		if (Coins[i].Location.y <= 0.5)Coins[i].Status = 0;
	}
	for (int i = 0; i < 10; i++) {
		Repairs[i].Rotation.y = ((int)Coins[i].Rotation.y + 2) % 360;
		if (Repairs[i].Status)Repairs[i].Location.y -= 0.1;
		if (Repairs[i].Location.y <= 0.5)Repairs[i].Status = 0;

	}
	BuildBounds(&Player1);
	BuildBounds(&Player2);
	HeliBounds(&Player1, &Player2);
	HeliBounds(&Player2, &Player1);
	TankBounds(&Player1, &Player2);
	TankBounds(&Player2, &Player1);
	BaseBuildBound(&Player1, &Player2);
	BaseBuildBound(&Player2, &Player1);
	BuildBoxBounds(&Player1);
	BuildBoxBounds(&Player2);

	for (int i = 0; i < BuildsCount; i++)MapBuildings[i].Move();
	HeliBuildBounds(&Player1);
	HeliBuildBounds(&Player2);
	BuildBoxHeliBounds(&Player1);
	BuildBoxHeliBounds(&Player2);
	Player1.Move(&Distance,&SendTank,&ground,&Player2);
	Player2.Move(&Distance, &SendTank, &ground, &Player1);
	Arrow.Move();
	for (int k = 0; k < BUILDBOX_COUNT; k++)
	{
		if (!BuildBoxes[k].Status)
			if (BuildBoxes[k].MoveV())
			{
				if (Player2.Heli.Status == 1  && Player2.Heli.GetBuildBox==&BuildBoxes[k]) {
					Player2.Heli.GetBuildBox = NULL;
					Player2.Heli.Status = 0;
				}
				if (Player2.Heli.Status == 2) {
					Player2.Heli.GetBuildBox = NULL;
					Player2.Heli.Status = 3;
				}
			}
		if (BuildBoxes[k].Location.y <= 1)BuildBoxes[k].BOUNDED = 1;
	}
	if (Player2.Heli.Status == 0 && !Player2.Heli.GetBuildBox )
	{
		int num = SearchBox();
		if (num != -1) {
			Player2.Heli.BoxToPut.Set_(Player2.Build.Location.x, 10, Player2.Build.Location.z);
			Player2.Heli.BoxToPut.Add(&Player2.Build.box[num].Location);
		}
		else
		{

		}
	}

	
	Station[0].Move();
	Station[1].Move();
	Station[2].Move();
	for (int i = 0; i < STARS_COUNT; i++)
		stars[i].Move();
	SpaceShip.Move();
	//SunDegree += 0.002;
	if (SunDegree > 360)SunDegree = 0;
	draw();
}
// Set OpenGL parameters
void PutBuilding(Building* b)
{
	int i, j, x, z, lx, lz, plus = 0;

	x = (b->box[0].Size.x + 2) / 2;
	z = (b->box[0].Size.z + 2) / 2;
	lx = b->Location.x / 2;
	if (b->BuildName == "CurBuild1F" ||
		b->BuildName == "CurBuild1B" ||
		b->BuildName == "CurBuild1R" ||
		b->BuildName == "CurBuild1L")
	{
		x-=1;
		z -= 1;
	}
	if (b->BuildName == "Build11M")
	{
		x -= 1;
		z -= 1;
	}
	if (b->BuildName == "Build8m")
	{
		x -= 1;
		z -= 1;
	}
	
	if (b->BuildName == "ClrdBuild1F" || b->BuildName == "ClrdBuild1B")
	{
		lx -= 1;
		x -= 1;
		z -= 1;
	}
	if (b->BuildName == "ClrdBuild1R" || b->BuildName == "ClrdBuild1L")
	{
		plus = 1;
		x -= 1;
		z -= 1;
	}

	if (b->BuildName == "Build4mF" || b->BuildName == "Build4mB")
	{
		lx -= 1;
		x -= 1;
		z -= 1;
	}
	if (b->BuildName == "Pyramid1")
	{
		lx -= 1;
		plus = 1;
		x += 2;
		z += 2;
	}
	if (b->BuildName == "Pyramid2" || b->BuildName == "PyTower1" || b->BuildName == "PyTower2")
	{
		x--;
		z--;
	}
	if (b->BuildName== "Build_3F" || b->BuildName== "Build_3B" ) {
		lx -= 1;
		x++;
	}
	if (b->BuildName== "Build_3R" || b->BuildName== "Build_3L" ) {
		plus = 1;
		z++;
	}
	if (b->BuildName== "Build_12F"  || b->BuildName== "Build_12B" )lx -= 1;
	if (b->BuildName== "Build_12R"  || b->BuildName== "Build_12L" )plus = 1;
	if (b->BuildName== "Build_1F"  || b->BuildName== "Build_1B" ) {
		lx -= 1;
		x++;
	}
	if (b->BuildName== "Build_1R" || b->BuildName== "Build_1L") 
	{
		z++;
		plus = 1;
	}
	if (b->BuildName == "Build4mR" || b->BuildName == "Build4mL") {
		--x;
		--z;	
		plus = 1;
	}
	if (b->BuildName == "BigTreeBF" ||
		b->BuildName == "BigTreeBB" ||
		b->BuildName == "BigTreeBR" ||
		b->BuildName == "BigTreeBL")
	{
		x = z = 1;
	}
	if (b->BuildName == "Station")
	{
		lx -= 1;
		plus = 1;
		x += 1;
		z += 1;
	}


	if (b->BuildName == "CurdBuild1F")return;
	if (b->BuildName == "CurdBuild1B")return;
	if (b->BuildName == "CurdBuild1R")return;
	if (b->BuildName == "CurdBuild1L")return;
	if (b->BuildName == "BUild8mBF")return;
	if (b->BuildName == "BUild8mBB")return;
	if (b->BuildName == "BUild8mBL")return;
	if (b->BuildName == "BUild8mBR")return;


	for (i = 0; i < x; i++, lx += 1) {
		lz = b->Location.z / 2 - plus;
		for (j = 0; j < z; j++, lz += 1)
			ground.Hold(lx, lz);
	}
}
void init()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 0, 0, 300);
	glMatrixMode(GL_MODELVIEW);

	// Lighting parameters
	GLfloat mat_ambdif[] = { 1, 1, 1, 0 };
	GLfloat mat_specular[] = { 1, 1, 1, 0.0 };
	GLfloat mat_diffuseLight[] = { 1,1,1,0 };
	GLfloat mat_shininess[] = { 80.0 };
	GLfloat light_position[] = { 1, 1, 1, 0.0 };

	GLfloat Light_Pos[] = { 0,0,-5,1.0f };
	GLfloat Light_Amb[] = { 1.0f,1.0f,1.0f,1.0f };
	GLfloat Light_Dif[] = { 0.6f,0.6f,0.6f,1.0f };
	GLfloat Light_Spe[] = { 0.2f,0.2f,0.2f,1.0f };
	//glClearColor(0.3, 0.3, 1.0, 0.0);
	glClearColor(0.1, 0.1, 0.3, 0.0);

	glMaterialfv(GL_LIGHT0, GL_AMBIENT, mat_ambdif);
	glMaterialfv(GL_LIGHT0, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_LIGHT0, GL_SHININESS, mat_shininess);
	glMaterialfv(GL_LIGHT0, GL_DIFFUSE, mat_diffuseLight);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);


	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);
	GLfloat a[] = { 0, -1, 0 };
	GLfloat C = 1, L = 0.007, Q = 0.0002;

	glLightfv(GL_LIGHT1, GL_POSITION, Light_Pos);
	glLightfv(GL_LIGHT1, GL_AMBIENT, Light_Amb);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, Light_Dif);
	glLightfv(GL_LIGHT1, GL_SPECULAR, Light_Spe);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 5);
	glLightfv(GL_LIGHT1, GL_POSITION, b);
	
	{
		C = 1; L = 0.14; Q = 0.07;
		glLightfv(GL_LIGHT2, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT2, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT2, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT2, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT2, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, Q);

		glLightfv(GL_LIGHT3, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT3, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT3, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT3, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT3, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT3, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT3, GL_QUADRATIC_ATTENUATION, Q);

		glLightfv(GL_LIGHT4, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT4, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT4, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT4, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT4, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT4, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT4, GL_QUADRATIC_ATTENUATION, Q);

		glLightfv(GL_LIGHT5, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT5, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT5, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT5, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT5, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT5, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT5, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT5, GL_QUADRATIC_ATTENUATION, Q);

		glLightfv(GL_LIGHT6, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT6, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT6, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT6, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT6, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT6, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT6, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT6, GL_QUADRATIC_ATTENUATION, Q);

		glLightfv(GL_LIGHT7, GL_POSITION, Light_Pos);
		glLightfv(GL_LIGHT7, GL_AMBIENT, Light_Amb);
		glLightfv(GL_LIGHT7, GL_DIFFUSE, Light_Dif);
		glLightfv(GL_LIGHT7, GL_SPECULAR, Light_Spe);
		glLightf(GL_LIGHT7, GL_SPOT_EXPONENT, 15);
		glLightf(GL_LIGHT7, GL_CONSTANT_ATTENUATION, C);
		glLightf(GL_LIGHT7, GL_LINEAR_ATTENUATION, L);
		glLightf(GL_LIGHT7, GL_QUADRATIC_ATTENUATION, Q);
	}

	C = 1; L = 0.004; Q = 0.0001;
	glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, C);
	glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, L);
	glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, Q);


	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glEnable(GL_DEPTH_TEST);


	for (int i = 0; i < STARS_COUNT; i++)
		stars[i].Location.Set_(70+(rand()%100),15+(i%4),(i%50)*2);
	
	int i = 0, BoxCnt;

	for (i = 0; i < 198; i++)Around[i].Size.Set_(2, 10 + rand() % 5, 2);
	for (i = 0; i < 60; i++)Around[i].Location.Set_(0-10, Around[i].Size.y / 2, i * 2-10);
	for (i = 60; i < 120; i++)Around[i].Location.Set_(58+10, Around[i].Size.y / 2, (i - 60) * 2-10);
	for (i = 120; i < 159; i++)Around[i].Location.Set_(2 + (i - 120) * 2-10, Around[i].Size.y / 2, 0-10);
	for (i = 159; i < 198; i++)Around[i].Location.Set_(2 + (i - 159) * 2-10, Around[i].Size.y / 2, 98+10);

	Arrow.Box_Count = 1;
	Arrow.Health = 100;
	Arrow.box[0].Moving_Rotation = 1;
	Arrow.box[0].RotationFrom.Set_(0, 0, 0);
	Arrow.box[0].RotationTo.Set_(0, 90, 0);
	Arrow.box[0].RotationSpeed.Set_(0, 5, 0);
	Arrow.box[0].Size.Set_(0.3, 0.3, 0.3);
	Arrow.box[0].Color.Set_(10, 10, 10);

	Player1.Coins = 100000;
	Player2.Coins = 200000;
	ShopTankMenuBack.init(-4.5, 2.5, 0.5, 1, 0, 0, "Back");
	ShopTankMenu[0].init(-4.0, -2.0, 0.5, 1, 1, 1, "Buy - 100");
	ShopTankMenu[1].init(-1.2, -2.0, 0.5, 1, 1, 1, "Buy - 150");
	ShopTankMenu[2].init(1.5, -2.0, 0.5, 1, 1, 1, "Buy - 200");
	ShopTankMenu[3].init(4, -2.0, 0.5, 1, 1, 1, "Buy - 200");

	ShopTankOrder[0].init(-3.0, 2.0, 0.5, 1, 1, 1, "IDLE");
	ShopTankOrder[1].init(-3.0, 1.5, 0.5, 1, 0, 0, "ATK_BASE");
	ShopTankOrder[2].init(-3.0, 1.0, 0.5, 1, 0, 0, "ATK_HELI");
	ShopTankOrder[3].init(-1.5, 2.0, 0.5, 0, 1, 0, "PRT_BASE");
	ShopTankOrder[4].init(-1.5, 1.5, 0.5, 0, 1, 0, "PRT_HELI");
	ShopTankOrder[5].init(-1.5, 1.0, 0.5, 0, 1, 0, "PRT_TANK");//<<------Tank Orders

	Maps[0].init(2.8, 1.0, 0.5, 10, 0,0, "Town");
	Maps[1].init(2.8, 1.5, 0.5, 10, 10, 0, "Desert");
	Maps[2].init(2.8, 2.0, 0.5, 0, 10, 0, "Forest");
	Maps[3].init(4, 1.0, 0.5, 10, 0,0, "TownE");
	Maps[4].init(4, 1.5, 0.5, 10, 10, 0, "DesertE");
	Maps[5].init(4, 2.0, 0.5, 0, 10, 0, "ForestE");


	Diffecult[0].init(3.5, 0.0, 0.5, 10, 10, 10, "Easy");
	Diffecult[1].init(3.5,-0.5, 0.5, 10, 10, 0, "Normal");
	Diffecult[2].init(3.5,-1.0, 0.5, 10, 0, 0, "Hard");

	LevelBtns[0].init(-3.5,-2.0, 0.5, 10, 10, 10, "Level_1");
	LevelBtns[1].init(-1.5,-2.0, 0.5, 10, 10, 0, "Level_2");
	LevelBtns[2].init(0.5,-2.0, 0.5, 10, 0, 0, "Level_3");

	LevelShows[0].PickBuild(17, "Level_1");
	LevelShows[1].PickBuild(17, "Level_2");
	LevelShows[2].PickBuild(21, "Level_3");
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < LevelShows[i].Box_Count; j++)
			LevelShows[i].BoxIn[j] = 1;
	LevelShows[0].Location.Set_(-17, -8, -25);
	LevelShows[1].Location.Set_(-7, -8, -25);
	LevelShows[2].Location.Set_(3, -8, -25);

	for (int i = 0; i < 4; i++) {
		ShowTank[i].PickBuild(i + 1);
		ShowTank[i].Location.Set_(-9 + i * 6, -3, -12);
	}
	SpaceShip.PickBuild(21, "SpaceShip");
	SpaceShip.Location.Set_(70, 40, -35);
	SpaceShip.Rotation.Set_(25, -35, 0);
	glEnable(GL_FOG); //enable the fog
	glFogi(GL_FOG_MODE, GL_EXP2); //set the fog mode to GL_EXP2
	glFogfv(GL_FOG_COLOR, fogColor); //set the fog color to
	glFogf(GL_FOG_DENSITY, density); //set the density to the
	glHint(GL_FOG_HINT, GL_DONT_CARE); // set the fog to look the
}
int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);	// RGB display, double-buffered, with Z-Buffer
	glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(10, 10);
	glutCreateWindow("3D");
	glutReshapeFunc(reshape);
	glutDisplayFunc(draw);						// Set the display function
	glutKeyboardFunc(keyboard);					// Set the keyboard function
	glutIdleFunc(idle);
	glutMouseFunc(glutMouseClick);
	glutFullScreen();
	glutPassiveMotionFunc(passiveMotionFunc);
	glutSetCursor(GLUT_CURSOR_LEFT_ARROW);

	init();
	glutMainLoop();							// Start the main event loop
}