#include "D_Vertex.cpp"
class Button
{
public:
	float x, y;
	char* strPointer;
	char str[80];
	float Side;
	D_Vertex Color;
	void init(float x, float y, float Side, float r, float g, float b, const char* str)
	{
		strcpy(this->str, str);
		this->x = x;
		this->y = y;
		this->Side = Side;
		Color.Set_(r, g, b);
	}
	void Draw_Button()
	{
		Color.Color_On();
		glBegin(GL_LINE_LOOP);
		glVertex3f(x + Side, y + Side / 3, -5);
		glVertex3f(x - Side, y + Side / 3, -5);
		glVertex3f(x - Side, y - Side / 3, -5);
		glVertex3f(x + Side, y - Side / 3, -5);
		glEnd();
		strPointer = str;
		glColor3f(Color.x, Color.y, Color.z);
		glRasterPos3f(x - 0.3, y, -5);
		do glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *strPointer); while (*(++strPointer));
	}
	int Clicked(int Mx, int My)
	{
		if (Mx > 770 + (x * 150) - (Side * 150) && Mx < 770 + (x * 150) + (Side * 150))
			if (My > 430 + (y * -150) - (Side * 50) && My < 430 + (y * -150) + (Side * 50))
				return 1;
		return 0;
	}
};
