#include "Box.cpp"


class BoundAble {
public:
	Box box[30];
	int Box_Count;
};
class MoveAble {
public:
	virtual void Move() = 0;
};
class DrawAble {
public:
	virtual void Draw() = 0;
};

class Node :public LocationAble{
public:
	int Status;
	Node *VisitedFrom[30][50];
	D_Vertex Color;
	Node()
	{
		Status = 1;
		for (int i = 0; i < 30; i++)
			for (int j = 0; j < 50; j++)
				VisitedFrom[i][j] = NULL;
	}
};
class Ground : public DrawAble{
public:
	int Type, FromX,FromY;
	Node Area[30][50];
	int stackI[1500];
	int stackJ[1500];
	int index,indexQ;
	int SizeX, SizeZ;
	void PickBuild(int opt)
	{
		
		index = 0;
		Type = opt;
		
		SizeX = 30;
		SizeZ = 50;
		for (int i = 0; i < SizeX; i++)
			for (int j = 0; j < SizeZ; j++) {
				Area[i][j].Location.Set_(2 * i, 0, 2 * j);
				if (Area[i][j].Color.x != 1)
				{
					if(Type == 1|| Type == 3)
						Area[i][j].Color.Set_(0, 0.7 + float(((i + j) % 10)) / 10, 0);
					if (Type == 2)
						Area[i][j].Color.Set_(0.7 + float(((i + j) % 10)) / 10, 0.7 + float(((i + j) % 10)) / 10, 0);
				}
			}
		Set_Neighbours();
	}
	void Set_Neighbours()
	{
		int i, j;
		for (i = 0; i < SizeX; i++)
			for (j = 0; j < SizeZ; j++){
				index=indexQ=0;
				FromX = i;
				FromY = j;
				Area[i][j].VisitedFrom[i][j]=&Area[i][j];
				BFS(i, j);
			}
		
	}
	void BFS(int i,int j)
	{
		if (i<0 || j < 0 || i>=SizeX|| j>=SizeZ)return;

		if (i > 0 && Area[i - 1][j].VisitedFrom[FromX][FromY] == NULL && Area[i - 1][j].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i - 1][j]) {
				Area[i - 1][j].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i - 1;
				stackJ[index++] = j;
			}

		}
		if (i < SizeX - 1 && Area[i + 1][j].VisitedFrom[FromX][FromY] == NULL && Area[i + 1][j].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i + 1][j]) {
				Area[i + 1][j].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i + 1;
				stackJ[index++] = j;

			}
		}
		if (j > 0 && Area[i][j - 1].VisitedFrom[FromX][FromY] == NULL && Area[i][j - 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i][j - 1]) {
				Area[i][j - 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i;
				stackJ[index++] = j - 1;

			}

		}
		if (j < SizeZ - 1 && Area[i][j + 1].VisitedFrom[FromX][FromY] == NULL && Area[i][j + 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i][j + 1]) {
				Area[i][j + 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i;
				stackJ[index++] = j + 1;

			}
		}
		if (i > 0 && j > 0 && Area[i - 1][j - 1].VisitedFrom[FromX][FromY] == NULL && Area[i - 1][j - 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i - 1][j - 1] && Area[i - 1][j].Status && Area[i][j - 1].Status) {
				Area[i - 1][j - 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i - 1;
				stackJ[index++] = j - 1;
			}
			
		}
		if (i < SizeX - 1 && j < SizeZ - 1 && Area[i + 1][j + 1].VisitedFrom[FromX][FromY] == NULL && Area[i + 1][j + 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i + 1][j + 1] && Area[i + 1][j].Status && Area[i][j + 1].Status) {
				Area[i + 1][j + 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i + 1;
				stackJ[index++] = j + 1;
			}

		}
		if (i > 0 && j < SizeZ - 1 && Area[i - 1][j + 1].VisitedFrom[FromX][FromY] == NULL && Area[i - 1][j + 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i-1][j+1] && Area[i - 1][j].Status && Area[i][j + 1].Status){
				Area[i - 1][j + 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i - 1;
				stackJ[index++] = j + 1;
			}
			
		}
		if (i < SizeX - 1 && j > 0 && Area[i + 1][j - 1].VisitedFrom[FromX][FromY] == NULL && Area[i + 1][j - 1].Status) {
			if (Area[i][j].VisitedFrom[FromX][FromY] != &Area[i+1][j-1] && Area[i + 1][j].Status && Area[i][j - 1].Status){
				Area[i + 1][j - 1].VisitedFrom[FromX][FromY] = &Area[i][j];
				stackI[index] = i + 1;
				stackJ[index++] = j - 1;
			}
		}
	

		while (indexQ!=index) {
			indexQ++;
			BFS(stackI[indexQ-1], stackJ[indexQ-1]);
		}
	}

	void Draw()
	{
		if(Type==1)glColor3f(0, 1, 0);
		if(Type==2)glColor3f(1, 1, 0);
		glBegin(GL_QUADS);
		glVertex3f(-200, -0.01, -200);
		glVertex3f(200, -0.01, -200);
		glVertex3f(200, -0.01, 200);
		glVertex3f(-200, -0.01, 200);
		glEnd();
		for(int i=0;i<SizeX;i++)
			for (int j = 0; j < SizeZ; j++)
			{
				Area[i][j].Go_Location();
				Area[i][j].Color.Color_On();
				glBegin(GL_QUADS);
				glVertex3f(-1, 0, -1);
				glVertex3f(1, 0, -1);
				glVertex3f(1, 0, 1);
				glVertex3f(-1, 0, 1);
				glEnd();
				Area[i][j].Back_Location();
			}

	}
	void Hold(int x, int z)
	{
		if (x < 0 || z < 0 || x >= 30 || z >= 50)return;
		Area[x][z].Status = 0;
		//Area[x][z].Color.Set_(1, 0, 0);
	
	}
	void Closest(int* x, int* y)
	{
		indexQ++;
		stackI[indexQ] = (*x);
		stackJ[indexQ++] = (*y);
		ReqClosest(x, y);
	}
	void ReqClosest(int* x, int* y)
	{
		*x = stackI[indexQ - 1];
		*y = stackJ[--indexQ];
		if (Area[*x][*y].Status)return;
		else {
			stackI[indexQ] = (*x) + 1;
			stackJ[indexQ++] = (*y);
			stackI[indexQ] = (*x) - 1;
			stackJ[indexQ++] = (*y) + 1;
			stackI[indexQ] = (*x);
			stackJ[indexQ++] = (*y) - 1;
			stackI[indexQ] = (*x) + 1;
			stackJ[indexQ++] = (*y) + 1;
			stackI[indexQ] = (*x) + 1;
			stackJ[indexQ++] = (*y) - 1;
			stackI[indexQ] = (*x) - 1;
			stackJ[indexQ++] = (*y) + 1;
			stackI[indexQ] = (*x) - 1;
			stackJ[indexQ++] = (*y) - 1;
			stackI[indexQ] = (*x) + 1;
			stackJ[indexQ++] = (*y) + 1;
		}
		ReqClosest(x, y);
	}
};

class Blow :public BoundAble, public LocationAble, public MoveAble, public DrawAble {
public:
	int Status, Type;
	float Radius, MidRadius,MaxRadius;
	D_Vertex Color;
	void PickBuild(int opt)
	{
		
		Type = opt;
		Status = 0;
		switch (opt)
		{
			case 1:
				
				MaxRadius = 0.8;
				MidRadius = 0.4;
				break;
			case 2:
				MaxRadius = 1;
				MidRadius = 0.8;
				break; 
			case 3:
				MaxRadius = 2;
				MidRadius = 1;
				break;
			case 4:
				Color.Set_(1, 0, 0);
				MaxRadius = 0.2;
				break;
			case 5:
				Color.Set_(1, 0, 0);
				MaxRadius = 0.9;
				break;
		}
	}
	void Draw()
	{
		if (!Status)return;
		Go_Location();
		Color.Color_On();
		glutSolidSphere(Radius,7,7);
		Back_Location();
	}
	void Move()
	{
		if (!Status)return;
		if (Type == 4 || Type ==5 ) {
			Radius += 0.1;
			if (Radius > MaxRadius )
				 Status=Radius = 0;
			return;
		}


		Radius += 0.05;
		if (Radius >= MidRadius)Color.Set_(1, 0, 0);
		if (Radius >= MaxRadius) { Color.Set_(0, 0, 0); Location.y += 0.1; }
		if (Radius > MaxRadius + 0.5) { 
			Status = 2;
			Radius = 0;
		}
	}

};
class Bang: public LocationAble, public MoveAble, public DrawAble {
public:
	int Status, Type;
	Blow blow[4];
	void PickBuild(int opt)
	{
		Type = opt;
		Status = 0;
		switch (opt)
		{
		case 1:
		case 2:
			blow[0].PickBuild(1);
			blow[1].PickBuild(1);
			blow[2].PickBuild(2);
			blow[3].PickBuild(3);
			break;
		}
	}
	void Draw()
	{
		if (!Status)return;
		for (int i = 0; i < 4; i++)blow[i].Draw();
	}
	void Move()
	{
		int i;
		if (!Status)return;
		for ( i = 0; i < 4; i++)blow[i].Move();
		switch (Type)
		{
		case 1 :
			blow[0].Location.z += 0.08;
			blow[1].Location.x += 0.05;
			blow[2].Location.z -= 0.07;
			break;
		case 2:
			blow[0].Location.z += 0.09;
			blow[1].Location.x += 0.1;
			blow[3].Location.x -= 0.04;
			blow[3].Location.y += 0.06;
			blow[2].Location.z -= 0.03;
			blow[2].Location.y += 0.05;
			break;
		}
		for (i = 0; i < 4; i++)if(blow[i].Status!=2)break;
		if (i == 4)
		{
			for (i = 0; i < 4; i++)blow[i].Status = 0;
			Status = 0;
		}
	}
	void BlowFunc()
	{
		Status = 1;
		for (int i = 0; i < 4; i++)
		{
			blow[i].Color.Set_(1, 1, 0);
			blow[i].Location.Set_(Location.x, Location.y, Location.z);
			blow[i].Status = 1;
		}
	}
};
class Building : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	int Status;
	int Health;
	int Type;
	char BoxIn[30];
	string BuildName;
	void PickBuild(int opt,string Name)
	{
		Health = 100;
		string path;
		BuildName = Name;
		Box_Count = opt;
		path = "ObjectsBin\\" + Name + "_Bin";
		ifstream MyFile(path, ios::in | ios::binary);
		if (!MyFile)
			return;
		for (int i = 0; i < Box_Count; i++) {
			MyFile.read((char*)&box[i], sizeof(Box));
			BoxIn[i] = 1;
		}
		MyFile.close();
		if (Name.rfind("Level", 0) == 0) 
			for (int i = 1; i < Box_Count; i++)
				BoxIn[i] = 0;
		
	}
	void Move()
	{
		for (int i = 0; i < Box_Count; i++)
		box[i].move();
		if (Health <= 0 && Location.y>-20)
		{
			Location.y -= 0.05;
			for (int i = 0; i < Box_Count; i++) {
				box[i].Location.x += (i % 2)?  0.001 : -0.001;
				box[i].Location.z += (i % 2) ? 0.001 : -0.001;
				box[i].Rotation.x += (i % 2) ? 0.3 : -0.2;
				box[i].Rotation.z += (i % 2) ? 0.4 : -0.5;
			}
		}
	}
	void Draw()
	{
		Go_Location();
		Rotation_Open(1, 1, 1);
		for (int i = 0; i < Box_Count; i++)
			if (BoxIn[i])box[i].Draw();
			else if(BuildName.rfind("Level", 0) == 0)
			{
				box[i].Color.Color_On();
				box[i].Go_Location();
				glutWireCube(1);
				box[i].Back_Location();
			}
		Rotation_Close(1, 1, 1);
		Back_Location();
	}

};
class Bullet : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	D_Vertex Speed;
	D_Vertex Color;
	GLdouble Radius;
	Blow blow;
	Blow smoke;
	int Status;
	char Damage;
	void PickBuild(int opt)
	{
		Box_Count = 1;
		switch (opt)
		{
		case 1:
			Color.Set_(0.7, 0.7, 0);
			Radius = 0.2;		
			box[0].Size.Set_(0.1, 0.1, 0.1);
			Damage = 50;
			break;
		case 2:
			Color.Set_(1, 1, 0);
			Radius = 0.1;		
			box[0].Size.Set_(0.05, 0.05, 0.05);
			Damage = 30;
			break;
		}
		blow.PickBuild(opt);
		smoke.PickBuild(4);

	}
	void Move()
	{
		if (!Status)return;
		if (blow.Status == 2) {
			blow.Status = Status = 0;
			return;
		}
		Location.Add(&Speed);
		blow.Move();
		smoke.Move();
		if (!smoke.Status) {
			smoke.Location.Set_(Location.x, Location.y, Location.z);
			smoke.Status = 1;
		}
		if ((Location.y < 0 && !blow.Status) ||Status==50) {
			Location.y = 0.1;
			BlowFunc();
		}
		Status += 1;
	}
	void Draw()
	{
		if (!Status)return;
		if (!blow.Status) {
			Go_Location();
			Rotation_Open(1, 1, 1);
			Color.Color_On();
			glutSolidSphere(Radius, 7, 7);
			Rotation_Close(1, 1, 1);
			Back_Location();
			smoke.Draw();
		}
		blow.Draw();
		
	}
	void BlowFunc()
	{
		blow.Color.Set_(1, 1, 0);
		blow.Location.Set_(Location.x, Location.y, Location.z);
		blow.Status = 1;
	}
};

class BuildBox : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	int Status;
	int ReRand;
	char BOUNDED;
	string BoxColor;
	void PickBuild(string Name)
	{
		Status = 0;
		BOUNDED = 0;
		BoxColor = Name;
		Box_Count = 1;
		string path;
		path = "ObjectsBin\\" + Name + "_Bin";
		ifstream MyFile(path, ios::in | ios::binary);
		if (!MyFile)
			return;
		MyFile.read((char*)&box[0], sizeof(Box));
		MyFile.close();
	}
	void Move() {}
	int MoveV()
	{
		box[0].move();
		if (!BOUNDED)
			Location.y -= 0.1;
		ReRand++;

		if (ReRand == 500)
		{
			RandBox();
			return 1;
		}
		return 0;
	}
	void RandBox()
	{
		D_Vertex save;
		save.Set_(box[0].LocationFrom.x
			, box[0].LocationFrom.y
			, box[0].LocationFrom.z);

		int  r = rand() % 10;
		switch (r)
		{
		case 0:
			this->PickBuild("YellowBox");
			break;
		case 1:
		case 2:
			this->PickBuild("RedBox");
			break;
		case 3:
		case 4:
		case 5:
			this->PickBuild("BlackBox");
			break;
		default:
			this->PickBuild("BlueBox");
			break;

		}
		Location.Set_(save.x, save.y, save.z);
		box[0].LocationFrom.Set_(save.x, save.y, save.z);
		ReRand = 0;
	}
	void Draw()
	{
		Go_Location();
		Rotation_Open(1, 1, 1);
		box[0].Draw();
		Rotation_Close(1, 1, 1);
		Back_Location();
	}
};
class Helicopter : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	char Team,Destroying,AirStop;
	int Health;
	D_Vertex speed;
	D_Vertex Start;
	Bullet bullet[10];
	BuildBox *GetBuildBox;
	Box body;
	BuildBox* BB;
	int BulletIndex;
	int Reload,L,Up;
	int Type;
	int Status;
	D_Vertex BoxToPut;
	void PickBuild(int opt)
	{
		Status = 0;
		Health = 100;
		Type = opt;
		BB = GetBuildBox = NULL;
		string FileTxt;
		for (int i = 0; i < 10; i++)
			bullet[i].Status = 0;
		BB = NULL;
		switch (opt)
		{
		case 1:
			FileTxt = "FHeli_1_Bin";
			for(int i=0;i<10;i++)
				bullet[i].PickBuild(2);
			Box_Count = 12;
			L = 1;
			Up = 20;
			body.Location.Set_(0, 0, 0);
			body.Size.Set_(1.4,0.4,1.4);
			break;
		case 2:
			FileTxt = "Q_Heli_Bin";
			for (int i = 0; i < 10; i++)
				bullet[i].PickBuild(2);
			Box_Count = 16;
			L = 1;
			Up = 20;
			body.Location.Set_(0, 0, 0);
			body.Size.Set_(1.4, 0.4, 1.4);
			break;
		}
		ifstream MyFile(FileTxt, ios::in | ios::binary);
		if (!MyFile)
			return;
		for (int i = 0; i < Box_Count; i++)
			MyFile.read((char*)&box[i], sizeof(Box));
		MyFile.close();
		if (Type == 1)
		{
			for (int i = 0; i < Box_Count; i++)
				box[i].Location.y -= 0.7;
		}
	}
	void Move()
	{
		int i;
		if (AirStop)
		{
			if (Reload)Reload--;
			for (i = 0; i < 10; i++)bullet[i].Move();
			return;
		}
		if (Destroying)
		{
			for (int i = 0; i < Box_Count; i++)
			{
				box[i].Location.x += (i % 2) ? 0.1 : -0.1;
				box[i].Location.z += (i % 2) ? 0.1 : -0.1;
				box[i].Location.y -= 0.5;
				box[i].Rotation.x += (i % 2) ? 3 : -2;
				box[i].Rotation.z += (i % 2) ? 4 : -5;
			}

			if (Destroying == 10)
			{
				Destroying = 0;
				Location.Set_(Start.x, Start.y, Start.z);
				PickBuild(Type);
				return;
			}
			Destroying++;
			return;
		}
		for (i = 0; i < Box_Count; i++)box[i].move();
		if (Type == 1)
			box[8].Rotation.y = (int)(box[8].Rotation.y + Up) % 360;
		if (Type == 2)
		{
			box[9].Rotation.y = (int)(box[9].Rotation.y + Up) % 360;
			box[10].Rotation.y = (int)(box[10].Rotation.y + Up) % 360;
			box[11].Rotation.y = (int)(box[11].Rotation.y + Up) % 360;
			box[12].Rotation.y = (int)(box[12].Rotation.y + Up) % 360;
		}
		if (Team == 2)
		{
			if (Status && !GetBuildBox)Status = 0;
			if (GetBuildBox)
			{
				if (Status == 1) {
					RotateUntil_Y(Location, GetBuildBox->Location, 0);
					if (GetBuildBox->Location.x > Location.x)Location.x += 0.12;
					if (GetBuildBox->Location.x < Location.x)Location.x -= 0.12;
					if (GetBuildBox->Location.z > Location.z)Location.z += 0.12;
					if (GetBuildBox->Location.z < Location.z)Location.z -= 0.12;
					if (abs(GetBuildBox->Location.x - Location.x) < 0.12)
						if (abs(GetBuildBox->Location.z - Location.z) < 0.12)
						{
							Location.x = GetBuildBox->Location.x;
							Location.z = GetBuildBox->Location.z;
							Status = 2;
						}
					if (GetBuildBox->Status == 1) {
						Status = 3;
						GetBuildBox = NULL;
					}
				}
				if (Status == 2)
				{
					Location.y -= 0.12;
					if (GetBuildBox->Status == 1)
						Status = 3;
					
				}
				if (Status == 3)
				{

					if(Location.y<10)
						Location.y += 0.12;
					else
					{
						Location.y = 10;
						if (BB)Status = 4;
						else {
							Status = 0;
							GetBuildBox = NULL;
						}
					}
				}
				if (Status == 4) 
				{
					RotateUntil_Y(Location, BoxToPut, 0);
					if (BoxToPut.x > Location.x)Location.x += 0.12;
					if (BoxToPut.x < Location.x)Location.x -= 0.12;
					if (BoxToPut.z > Location.z)Location.z += 0.12;
					if (BoxToPut.z < Location.z)Location.z -= 0.12;
					if (abs(BoxToPut.x - Location.x) < 0.12)
						if (abs(BoxToPut.z - Location.z) < 0.12)
						{
							Location.x = BoxToPut.x;
							Location.z = BoxToPut.z;
							DropBox();
							GetBuildBox = NULL;
							Status = 0;
						}
				}	
			}
			return;
		}
		if (Rotation.x < 0)ForWard();
		else if (Rotation.x > 0)BackWard();
		else {
			speed.x += (speed.x < 0) ? 0.01 : -0.01;
			speed.z += (speed.z < 0) ? 0.01 : -0.01;
		}
		if (Rotation.z < 0)LeftWard();
		else if (Rotation.z > 0)RightWard();
		else {
			speed.x += (speed.x < 0) ? 0.01 : -0.01;
			speed.z += (speed.z < 0) ? 0.01 : -0.01;
		}
		if (speed.x < -0.12)speed.x = -0.12;
		if (speed.x > 0.12)speed.x = 0.12;
		if (speed.z < -0.12)speed.z = -0.12;
		if (speed.z > 0.12)speed.z = 0.12;
		Location.Add(&speed);
		for (i = 0; i < 10; i++)bullet[i].Move();
		if(Reload)Reload--;
		box[8].Moving_Rotation = 0;
		
		speed.y = (Up-20)*0.01;
		if (Location.y < 0) {
			Location.y =0;
			Up = 20;
		}
		if (Location.y >12) {
			Location.y = 12;
			Up = 20;
		}
		if (Location.x <= 3)Location.x = 3;
		if (Location.x >= 55)Location.x = 55;
		if (Location.z <= 3)Location.z = 3;
		if (Location.z >= 95)Location.z = 95;
	}
	void ForWard()
	{
		speed.x += sin((Rotation.y * PI) / 180.0)*( Rotation.x / 5000);
		speed.z += cos((Rotation.y * PI) / 180.0) * (Rotation.x / 5000);
	}
	void BackWard()
	{
		speed.x -= sin(((180 + Rotation.y) * PI) / 180.0) * (Rotation.x / 5000);
		speed.z -= cos(((180 + Rotation.y) * PI) / 180.0) * (Rotation.x / 5000);
	}
	void LeftWard()
	{
		speed.x += sin(((Rotation.y - 90) * PI) / 180.0) * (Rotation.z / 5000);
		speed.z += cos(((Rotation.y - 90) * PI) / 180.0) * (Rotation.z / 5000);
	}
	void RightWard()
	{
		speed.x -= sin(((90 + Rotation.y) * PI) / 180.0) * (Rotation.z / 5000);
		speed.z -= cos(((90 + Rotation.y) * PI) / 180.0) * (Rotation.z / 5000);
	}
	void Draw()
	{
		int i;
		Go_Location();
		Rotation_Open(1, 1, 1);
		for (i = 0; i < Box_Count; i++)
			box[i].Draw();
		if (BB) {
			BB->box[0].Rotation_Close(1,1,1);
			BB->Draw();
			BB->box[0].Rotation_Open(1,1,1);
		}
		Rotation_Close(1, 1, 1);
		Back_Location();
		for (i = 0; i < 10; i++)bullet[i].Draw();

	}
	void Fire()
	{
		if (Reload)return;
		bullet[BulletIndex].Location.Set_(Location.x, Location.y , Location.z);
		if (L) {
			bullet[BulletIndex].Location.x += sin(((Rotation.y - 90) * PI) / 180.0) * 0.5;
			bullet[BulletIndex].Location.z += cos(((Rotation.y - 90) * PI) / 180.0) * 0.5;
		}
		else {
			bullet[BulletIndex].Location.x -= sin(((Rotation.y - 90) * PI) / 180.0) * 0.5;
			bullet[BulletIndex].Location.z -= cos(((Rotation.y - 90) * PI) / 180.0) * 0.5;
		}
		L = !L;
		bullet[BulletIndex].Speed.x = sin((Rotation.y * PI) / 180.0) *  1.5;
		bullet[BulletIndex].Speed.y = sin((Rotation.x * PI) / 180.0) * -1.5;
		bullet[BulletIndex].Speed.z = cos((Rotation.y * PI) / 180.0) *  1.5;
		Reload = 5;
		bullet[BulletIndex].Status = 1;
		BulletIndex = (BulletIndex + 1) % 10;
	}
	void DropBox()
	{
		if (!BB)return;
		BB->Location.Set_(Location.x, Location.y-1, Location.z);
		BB->Status = BB->BOUNDED = 0;
		BB = NULL;
	}
	void Destroy()
	{
		DropBox();
		Destroying = 1;
	}
};

class Missile : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	int Type;
	int Status;
	char Damage;
	float Maxspeed;
	Bang bang;
	D_Vertex StartLocation, StartRotation;
	D_Vertex Speed;
	LocationAble *Target;
	LocationAble *SecTarget;
	LocationAble LandMissileAirTarget;
	void PickBuild(int opt)
	{
		Status = 0;
		Type = opt;
		string FileTxt;
		switch (opt)
		{
		case 1:
			bang.PickBuild(1);
			Maxspeed = 0.15;
			FileTxt = "FMissile_12_Bin";
			Box_Count = 6;
			Damage = 40;
			break;
		case 2:
			Damage = 50;
			bang.PickBuild(2);
			Maxspeed = 0.3;
			FileTxt = "FMissile_2_Bin";
			Box_Count = 7;
			break;
		}
		ifstream MyFile(FileTxt, ios::in | ios::binary);
		if (!MyFile)
			return;
		for (int i = 0; i < Box_Count; i++)
			MyFile.read((char*)&box[i], sizeof(Box));
		MyFile.close();
	}
	void Move()
	{
		if (Status)Status++;
		if (Location.y<=0 || Status == 200 && Type==1) {
			BlowFunc(); 
			return;
		}
		for (int i = 0; i < Box_Count; i++)
			box[i].move();
		
		if (Target != NULL)
		{
			
			if (Location.x < Target->Location.x)
				(Speed.x < 0 && Speed.x < Maxspeed) ? Speed.x += 0.05 : Speed.x += 0.005;
			else
				(Speed.x > 0 && Speed.x > 0 - Maxspeed) ? Speed.x -= 0.05 : Speed.x -= 0.005;

			if (Location.y < Target->Location.y)
				(Speed.y < 0 && Speed.y < Maxspeed) ? Speed.y += 0.05 : Speed.y += 0.005 ;
			else
				(Speed.y > 0 && Speed.y > 0 - Maxspeed) ? Speed.y -= 0.05 : Speed.y -= 0.005 ;

			if (Location.z < Target->Location.z)
				(Speed.z < 0 && Speed.z < Maxspeed) ? Speed.z += 0.05 : Speed.z += 0.005 ;
			else
				(Speed.z > 0 && Speed.z > 0 - Maxspeed) ? Speed.z -= 0.05 : Speed.z -= 0.005 ;
			
			if (Type == 2) {
				if (Status < 50)Speed.Set_(0, 0.2, 0);

				if (abs(Location.x - Target->Location.x) < 1)
					if (abs(Location.z - Target->Location.z) < 1)
						if (abs(Location.z - Target->Location.z) < 1)
							Target = SecTarget;
			}
			
			if (Type == 1 || Status >= 50)
			{
				RotateUntil_Y(Location, Target->Location, 0);
				RotateUntil_X_Half(Location, Target->Location, 0);
			}
			Location.Add(&Speed);
			
		}
		bang.Move();
	}	
	void Draw()
	{
		glEnable(GL_LIGHT0);
		Go_Location();
		Rotation_Open(1, 1, 1);
		for (int i = 0; i < Box_Count; i++)
			box[i].Draw();
		Rotation_Close(1, 1, 1);
		Back_Location();
		bang.Draw();
		glDisable(GL_LIGHT0);

	}
	void BlowFunc()
	{
		Status = 0;
		Target = NULL;
		bang.Location.Set_(Location.x, Location.y, Location.z);
		bang.BlowFunc();
		Speed.Set_(0, 0, 0);
		Location.Set_(StartLocation.x, StartLocation.y, StartLocation.z);
		Rotation.Set_(StartRotation.x, StartRotation.y, StartRotation.z);
	}

};
class Cannon : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	int Type;
	Missile missile_1, missile_2;
	void PickBuild(int opt)
	{
		Type = opt;
		string FileTxt;
		switch (opt)
		{
		case 1:
			FileTxt = "FCan_1_Bin";
			Box_Count = 5;
			break;
		case 2:
			FileTxt = "FCan_2_Bin";
			Box_Count = 7;
			break;
		case 3:
			FileTxt = "FCan_3_Bin";
			Box_Count = 8;
			missile_1.PickBuild(1);
			missile_2.PickBuild(1);
			missile_1.Rotation.Set_(-35, 0, 0);
			missile_2.Rotation.Set_(-35, 0, 0);
			missile_1.Location.Set_(-0.25,0.4,0);
			missile_2.Location.Set_(0.25,0.4,0);
			missile_1.StartRotation.Set_(-35, 0, 0);
			missile_2.StartRotation.Set_(-35, 0, 0);
			missile_1.StartLocation.Set_(-0.25, 0.4, 0);
			missile_2.StartLocation.Set_(0.25, 0.4, 0);
			break;
		}
		ifstream MyFile(FileTxt, ios::in | ios::binary);
		if (!MyFile)
			return;
		for (int i = 0; i < Box_Count; i++)
			MyFile.read((char*)&box[i], sizeof(Box));
		MyFile.close();
	}
	void Move()
	{
		for (int i = 0; i < Box_Count; i++)
			box[i].move();
	}
	void Draw()
	{
		Go_Location();
		Rotation_Open(1, 1, 1);
		switch (Type)
		{
		case 1:
			DrawType1();
			break;
		case 2:
			DrawType2();
			break;
		case 3:
			DrawType3();
			break;
		}
		Rotation_Close(1, 1, 1);
		Back_Location();
	}
	void DrawType1()
	{
		for (int i = 0; i < Box_Count; i++)box[i].Draw();	
	}
	void DrawType2()
	{
		for (int i = 0; i < Box_Count; i++)
		{
			if (i != 5)Rotation_Close(1, 0, 1);
			box[i].Draw();
			if (i != 5)Rotation_Open(1, 0, 1);
		}
	}
	void DrawType3()
	{
		for (int i = 0; i < Box_Count; i++)
			box[i].Draw();
		if (!missile_1.Status && !missile_1.bang.Status) missile_1.Draw();
		if (!missile_2.Status && !missile_2.bang.Status) missile_2.Draw();
	}
};
class Tank : public LocationAble, public RotationAble, public MoveAble, public DrawAble, public BoundAble {
public:
	char Team;
	char Price;
	int Health;
	int Type,Reload,ReloadTime, BulletIndex,PathIndex,PathQ;
	char Deploying;
	char Order;
	char Status;
	char Range;
	float GoX, GoZ;
	Tank *Protect, *ProtectBy;
	Missile missile;
	Bullet bullet[5];
	Cannon cannon;
	LocationAble *Target;
	LocationAble *OrderTarget;
	Node *Path[150];
	void PickBuild(int opt)
	{
		Type = opt; 
		Health = 100;
		string FileTxt;
		switch (opt)
		{
		case 1:
			Range = 15;
			Price = 100;
			FileTxt = "FTank_1_Bin";
			Box_Count = 17;
			cannon.PickBuild(1);
			cannon.Location.Set_(0, 0.5, 0);
			bullet[0].PickBuild(2);
			ReloadTime = 100;
			break;
		case 2:
			Range = 20;
			Price = 150;
			FileTxt = "FTank_1_Bin";
			Box_Count = 17;
			cannon.PickBuild(2);
			cannon.Location.Set_(0, 0.5, 0);
			for (int i = 0; i < 5; i++)
				bullet[i].PickBuild(2);
			ReloadTime = 10;
			break;

		case 3:
			Range = 25;
			Price = 200;
			FileTxt = "FTank_1_Bin";
			Box_Count = 17;
			cannon.PickBuild(3);
			cannon.Location.Set_(0, 0.5, 0);
			ReloadTime = 100;
			break;
		case 4:
			Range = 30;
			Price = 200;
			FileTxt = "FTank_2_Bin";
			Box_Count = 17;
			ReloadTime = 500;
			missile.PickBuild(2);
			missile.StartLocation.Set_(0, 0.7, -0.4);
			missile.Location.Set_(0, 0.7, -0.4);
			missile.StartRotation.Set_(-90, 0, 0);
			missile.Rotation.Set_(-90, 0, 0);
			break;
		}
		ifstream MyFile(FileTxt, ios::in | ios::binary);
		if (!MyFile)
			return;
		for (int i = 0; i < Box_Count; i++)
			MyFile.read((char*)&box[i], sizeof(Box));
		MyFile.close();
	}
	void Move()
	{

	}
	void Move(float (*Distance)(LocationAble*, LocationAble*) , void (*SendTank)(Tank*,int ,int),Ground *ground)
	{
		for (int i = 0; i < Box_Count; i++) 
			box[i].move();
		if (Deploying >= 1 && Deploying <= 30)//deploying
		{
			Location.z += (Team == 1)?-0.1:0.1;
			Rotation.y = (Team == 1)?180:0;
			Deploying++;
			return;
		}
		if (Reload)Reload--;
		
		if (Order == ATTACK_BASE);
		if (Order == ATTACK_HELICOPTER);
		if (Order == PROTECT_BASE);
		if (Order == PROTECT_TANK)
		{
			if (Protect && Protect->Status != 0 || Protect->Target)
			{
				if(Team==1)
					SendTank(this, (int)Protect->Location.x / 2, (int)Protect->Location.z / 2 -2);
				else
					SendTank(this, (int)Protect->Location.x / 2, (int)Protect->Location.z / 2 + 2);
			}
		}
		if (Order == PROTECT_HELICOPTER);
		if (Order == IDLE_TANK);
		if (OrderTarget)
		{
			if (Distance(this, OrderTarget) < Range) {
				Status = 0;
				Target = OrderTarget;
			}
			else
			{
				Target = NULL;
				if (!Status)
					SendTank(this, OrderTarget->Location.x / 2, OrderTarget->Location.z / 2);
			}

		}
		if (Target && Distance(this, Target) >= Range)
			Target = NULL;
		switch(Type)
		{
		case 1:
			Move_Type1();
			break;
		case 2:
			Move_Type2();
			break;
		case 3:
			Move_Type3();
			for (int i = 0; i < cannon.Box_Count; i++)
				cannon.box[i].move();
			break;
		case 4:
			Move_Type4();
			break;
		}
		if (Status)
		{
			if (PathIndex != PathQ) {
				RotateUntil_Y(Location, Path[PathQ]->Location, 0);
				if (Path[PathQ]->Location.x > Location.x)Location.x += 0.1;
				if (Path[PathQ]->Location.x < Location.x)Location.x -= 0.1;
				if (Path[PathQ]->Location.z > Location.z)Location.z += 0.1;
				if (Path[PathQ]->Location.z < Location.z)Location.z -= 0.1;
				if (abs(Path[PathQ]->Location.x - Location.x) < 0.1)
					if (abs(Path[PathQ]->Location.z - Location.z) < 0.1)
					{
						Location.x = Path[PathQ]->Location.x;
						Location.z = Path[PathQ]->Location.z;
						PathQ++;
					}
			}
			else
				Status = 0;
			
		}
	}
	void Move_Type1()
	{
		
		if (Target) {
			cannon.RotateUntil_Y(Location, Target->Location, -Rotation.y);
			Fire();
		}
		bullet[0].Move();

	}
	void Move_Type2()
	{
		if (Target) {
			cannon.RotateUntil_Y(Location, Target->Location, -Rotation.y);
			cannon.RotateUntil_X_Half(Location, Target->Location, 0);
			Fire();
		}
		for (int i = 0; i < 5; i++)
			bullet[i].Move();
	}
	void Move_Type3()
	{
		if (Target) {
			cannon.RotateUntil_Y(Location, Target->Location, -Rotation.y);
			Fire();
		}
		cannon.missile_1.Move();
		cannon.missile_2.Move();
	}
	void Move_Type4()
	{
		if(Target)Fire();
		missile.Move();
	}
	void Draw()
	{
		if (ProtectBy)
		{
			glColor3f(10, 0, 0);
			glBegin(GL_LINES);
			glVertex3f(Location.x,1,Location.z);
			glVertex3f(ProtectBy->Location.x,1, ProtectBy->Location.z);
			glEnd();
		}

		Go_Location();
		Rotation_Open(1, 1, 1);
		for (int i = 0; i < Box_Count; i++)
			box[i].Draw();
	
		if (Type == 4 &&!missile.Status && !missile.bang.Status) missile.Draw();
		if(Type!=4)
			cannon.Draw();
		Rotation_Close(1, 1, 1);
		Back_Location();
		switch (Type) {
		case 1:
				bullet[0].Draw();
			break;
		case 2:
			for (int i = 0; i < 5; i++)
				bullet[i].Draw();
			break;
		case 3:
			if (cannon.missile_1.Status)cannon.missile_1.Draw();
			if (cannon.missile_2.Status)cannon.missile_2.Draw();
			cannon.missile_1.bang.Draw();
			cannon.missile_2.bang.Draw();
			break;
		case 4:
			if (missile.Status)missile.Draw();
			missile.bang.Draw();
			break;
		}
		
	}
	void Fire()
	{
		if (Reload)return;
		switch (Type)
		{
		case 1:
			Fire_Tank1();
			break;
		case 2:
			Fire_Tank2();
			break;
		case 3:
			Fire_Tank3();
			break;
		case 4:
			Fire_Tank4();
			break;
		}
		
	}
	void Fire_Tank1()
	{
		if (bullet[0].Status)return;
		bullet[0].Location.Set_(Location.x, Location.y + 0.5, Location.z);
		bullet[0].Speed.x = sin(((cannon.Rotation.y + Rotation.y) * PI) / 180.0) * 0.5;
		bullet[0].Speed.z = cos(((cannon.Rotation.y + Rotation.y) * PI) / 180.0) * 0.5;
		bullet[0].Status = 1;
		Reload = ReloadTime;
	}
	void Fire_Tank2()
	{
		if (bullet[BulletIndex].Status)return;
		bullet[BulletIndex].Location.Set_(Location.x, Location.y + 0.7, Location.z);
		bullet[BulletIndex].Speed.x = sin(((cannon.Rotation.y + Rotation.y) * PI) / 180.0) * 0.5;
		bullet[BulletIndex].Speed.y = sin((cannon.Rotation.x * PI) / 180.0) * -0.5;
		bullet[BulletIndex].Speed.z = cos(((cannon.Rotation.y + Rotation.y) * PI) / 180.0) * 0.5;
		bullet[BulletIndex].Status = 1;
		BulletIndex = (BulletIndex + 1) % 5;
		Reload = ReloadTime;
	}
	void Fire_Tank3()
	{
		if (cannon.missile_1.Target == NULL)
		{
			cannon.missile_1.Target = Target;
			cannon.missile_1.Location.x+=Location.x;
			cannon.missile_1.Location.y+=Location.y;
			cannon.missile_1.Location.z+=Location.z;
			cannon.missile_1.Status = 1;
			Reload = ReloadTime;
			return;
		}
		if (cannon.missile_2.Target == NULL) {
			cannon.missile_2.Target = Target;
			cannon.missile_2.Location.x += Location.x;
			cannon.missile_2.Location.y += Location.y;
			cannon.missile_2.Location.z += Location.z;
			cannon.missile_2.Status = 1;
			Reload = ReloadTime;
			return;
		}
	}
	void Fire_Tank4() {
		if (missile.Target == NULL)
		{
			missile.SecTarget = Target;
			missile.Target = &missile.LandMissileAirTarget;
			missile.LandMissileAirTarget.Location.Set_((Location.x+Target->Location.x)/2,
												20, 
												(Location.z + Target->Location.z) / 2 );
			missile.Location.x += Location.x;
			missile.Location.y += Location.y;
			missile.Location.z += Location.z;
			missile.Status = 1;
			Reload = ReloadTime;
			return;
		}
	}
	void Destroy()
	{
		Order = IDLE_TANK;
		if (Protect)Protect->ProtectBy = NULL;
		if (ProtectBy) {
			ProtectBy->Order = IDLE_TANK;
			ProtectBy->Protect = NULL;
		}
		ProtectBy =Protect = NULL;
		Target = OrderTarget = NULL;
	}
	void GetPath(Ground* g, int x, int z)
	{
		Node* n;
		int cx, cz;
		cx = (int)Location.x / 2;
		cz = (int)Location.z / 2;
		if (!g->Area[cx][cz].Status)
			return ;
		PathIndex = Status = PathQ = 0;;
		n = &g->Area[cx][cz];
		if (!g->Area[x][z].Status)return ;
		while (n != &g->Area[x][z])
		{
			if (n == NULL)return ;
			Path[PathIndex++] = n->VisitedFrom[x][z];
			n = n->VisitedFrom[x][z];
		}
		Status = 1;
		return ;
	}
	void Protect_Tank(Tank *other)
	{
		Order = PROTECT_TANK;
		Protect = other;
		other->ProtectBy = this;
	}
};

class Player
{
public:
	char Count;
	char Plan;
	int Status;
	int DifficultSpeed = 250;
	char Difficult;
	char Team;
	int Coins;
	int TankIndex;
	int TanksIn[10];
	int TanksSetTest[3][3][10][3];
	int BotBuyIndex;
	Helicopter Heli;
	Building Build, TankBuild;
	Tank Tanks[10];
	void PickBuild(int opt, float x, float y, float z, float ry, string Level, char TeamNumber)
	{
		Heli.Status = 0;
		Heli.GetBuildBox = NULL;
		Plan = MID_PLAN;
		Heli.PickBuild(2);
		Heli.Location.Set_(x, y, z);
		Heli.Start.Set_(x, y, z);
		Heli.Rotation.y = ry;
		Build.PickBuild(17, Level);
		Build.Location.Set_(x, 0, z);
		Team = TeamNumber;
		for (int i = 0; i < 10; i++) {
			Tanks[i].Team = TeamNumber;
			TanksIn[i] = 0;
		}
		Heli.Team = TeamNumber;
		TankBuild.PickBuild(12, "TankBuild");
		TankBuild.Location.Set_(x, -0.01, z);
		if (TeamNumber == 2)TankBuild.Location.x += 4;
		else TankBuild.Location.x -= 4;
	}
	int Finished()
	{
		for (int i = 1; i < Build.Box_Count; i++)
			if (Build.BoxIn[i] == 0)return 0;
		return 1;
	}
	int BuyTank(int Type, Ground* g)
	{
		int i;
		for (i = 0; i < 10; i++)
			if (!TanksIn[i])break;
		if (i == 10)return 0;
		Tanks[i].PickBuild(Type);
		if (Tanks[i].Price > Coins)return 0;
		Coins -= Tanks[i].Price;
		Tanks[i].Location.Set_(TankBuild.Location.x, TankBuild.Location.y, TankBuild.Location.z);
		Tanks[i].Deploying = 1;
		TanksIn[i] = 1;
		if (Team == 1)
			Tanks[i].GetPath(g, (int)(TankBuild.Location.x / 2) + ((i % 5) - 2), (int)(TankBuild.Location.z / 2) - ((i / 5) + 2));
		else
			Tanks[i].GetPath(g, (int)(TankBuild.Location.x / 2) - ((i % 5) - 2), (int)(TankBuild.Location.z / 2) + ((i / 5) + 2));
		Tanks[i].Order = IDLE_TANK;
		Tanks[i].Protect = Tanks[i].ProtectBy = NULL;
		Tanks[i].cannon.Rotation.Set_(0, 0, 0);

		return i;

	}
	void Draw()
	{
		Heli.Draw();
		Build.Draw();
		TankBuild.Draw();
		for (int i = 0; i < 10; i++)
			if (TanksIn[i])Tanks[i].Draw();

	}
	void BotMoveTest(float (*Distance)(LocationAble*, LocationAble*), void (*SendTank)(Tank*, int, int), Ground* ground, Player* other)
	{
		if (!Status)
		{
			if (BuyTank(TanksSetTest[Difficult][Plan][BotBuyIndex][2], ground))
				if (TanksIn[BotBuyIndex] && Tanks[BotBuyIndex].Type == 4)
					Tanks[BotBuyIndex].Order = ATTACK_BASE;
				
			
				for (int i = 0; i < 10; i++)
					if (TanksIn[i]) {
						SendTank(&Tanks[i], TanksSetTest[Difficult][Plan][i][0] / 2
							, TanksSetTest[Difficult][Plan][i][1] / 2);
						if(Tanks[i].Type == 4)
							Tanks[i].OrderTarget = &other->Build;
						
					}
			
			BotBuyIndex++;

		}
		BotBuyIndex %= 10;
		Status = (1 + Status) % DifficultSpeed;
	}
	void Move(float (*Distance)(LocationAble*, LocationAble*), void (*SendTank)(Tank*, int, int), Ground* ground, Player* other)
	{
		if (Team == 2)
		{
			BotMoveTest(Distance, SendTank, ground, other);
		}
		Heli.Move();
		TankBuild.Move();
		for (int i = 0; i < 10; i++)
			if (TanksIn[i])Tanks[i].Move(Distance, SendTank, ground);
		for (int i = 0; i < 10; i++)
			if (TanksIn[i])
			{
				Helicopter* H = &Heli;
				if (Tanks[i].Order == PROTECT_HELICOPTER)
					H = &Heli;
				else if (Tanks[i].Order == ATTACK_HELICOPTER)
					H = &other->Heli;
				else continue;
				if (Tanks[i].Status)return;
				Tank* tankpointer;
				tankpointer = &Tanks[i];
				int gx, gz;
				gx = ((int)H->Location.x / 2);
				gz = ((int)H->Location.z / 2);
				gz += (H->Team == 1) ? -2 : 2;
				while (tankpointer) {
					ground->Closest(&gx, &gz);
					tankpointer->GetPath(ground, gx, gz);
					gz += (H->Team == 1) ? -2 : 2;
					tankpointer = tankpointer->ProtectBy;
				}

			}
	}
	void ReBuild(Ground* ground)
	{
		int cnt = 0;
		for (int i = 0; i < 10; i++)
		{
			if (TanksIn[i] == 1)
			{
				Tanks[i].Target = Tanks[i].OrderTarget = NULL;
				Tanks[i].ProtectBy = Tanks[i].Protect = NULL;
				TanksIn[i] = 0;
				cnt++;
			}
		}
		for (int i = 0; i < cnt; i++)
		{
			BuyTank((const char)TanksSetTest[Difficult][Plan][i][2], ground);
			if (TanksIn[i] && Tanks[i].Type == 4)
			{
				Tanks[BotBuyIndex].Order = ATTACK_BASE;
				Tanks[BotBuyIndex].OrderTarget = NULL;
			}
		}
	}
	int Need()
	{
		return (Build.Box_Count - 1) - Count;
	}
};

class Star:public LocationAble
{
public:
	void Draw()
	{
		Go_Location();
		glutSolidCube(0.2);
		Back_Location();
	}
	void Move()
	{
		Location.x -= 0.5;
		if (Location.x < -10)Location.x = 70;
	}
};