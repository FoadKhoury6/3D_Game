#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>

#define ATTACK_HELICOPTER 100
#define ATTACK_BASE 101
#define PROTECT_BASE 102
#define PROTECT_TANK 103
#define PROTECT_HELICOPTER 105
#define IDLE_TANK 106
#define DEFEND_PLAN 0
#define MID_PLAN 1
#define ATTACK_PLAN 2
#define EASY_BOT 0
#define MID_BOT 1
#define HARD_BOT 2


#pragma warning(disable  : 4996)
using namespace std;
#define PI 3.141459

class D_Vertex
{
public:
	float x, y, z, a;
	D_Vertex(float x, float y, float z, float a = 0)
	{
		this->x = x;
		this->y = y;
		this->z = z;
		this->a = a;
	}
	D_Vertex()
	{
		x = y = z = a = 0;
	}
	D_Vertex(const D_Vertex& other)
	{
		x = other.x;
		y = other.y;
		z = other.z;
		a = other.a;
	}
	void Set_(float x, float y, float z, float a = 1)
	{
		this->x = x;
		this->y = y;
		this->z = z;
		this->a = a;
	}
	inline void INC_X(float Val = 0.1)
	{
		this->x += Val;
	}
	inline void INC_Y(float Val = 0.1)
	{
		this->y += Val;
	}
	inline void INC_Z(float Val = 0.1)
	{
		this->z += Val;
	}
	inline void INC_A(float Val = 0.1)
	{
		this->a += Val;
	}
	inline void Color_On()
	{
		glColor3f(x, y, z);
	}
	D_Vertex& operator =(const D_Vertex& other)
	{
		x = other.x;
		y = other.y;
		z = other.z;
		a = other.a;
		return *this;
	}
	void Add(D_Vertex* other)
	{
		this->x += other->x;
		this->y += other->y;
		this->z += other->z;
	}
	void Move(D_Vertex* From, D_Vertex* To, D_Vertex* Speed, bool ReqMove = false)
	{
		this->Add(Speed);
		if (ReqMove)
		{
			if (Speed->x < 0 && x < To->x)x = From->x;
			if (Speed->x > 0 && x > To->x)x = From->x;
			if (Speed->y < 0 && y < To->y)y = From->y;
			if (Speed->y > 0 && y > To->y)y = From->y;
			if (Speed->z < 0 && z < To->z)z = From->z;
			if (Speed->z > 0 && z > To->z)z = From->z;
		}
		else
		{

			if (x >= To->x || x <= From->x)Speed->x *= -1;
			if (y >= To->y || y <= From->y)Speed->y *= -1;
			if (z >= To->z || z <= From->z)Speed->z *= -1;
		}
	}
};
