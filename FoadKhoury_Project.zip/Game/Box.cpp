#include "Button.cpp"
class LocationAble {
public:
	D_Vertex Location;
	void Go_Location()
	{
		glTranslatef(Location.x, Location.y, Location.z);
	}
	void Back_Location()
	{
		glTranslatef(-Location.x, -Location.y, -Location.z);
	}
	void Add(D_Vertex* other)
	{
		Location.x += other->x;
		Location.y += other->y;
		Location.z += other->z;
	}
	void Move(D_Vertex* From, D_Vertex* To, D_Vertex* Speed)
	{
		this->Add(Speed);
		if (Location.x >= To->x || Location.x <= From->x)Speed->x *= -1;
		if (Location.y >= To->y || Location.y <= From->y)Speed->y *= -1;
		if (Location.z >= To->z || Location.z <= From->z)Speed->z *= -1;
	}

};
class RotationAble {
public:
	D_Vertex Rotation;
	void Rotation_Open(int f1, int f2, int f3)
	{
		if (f2)glRotatef(Rotation.y, 0, 1, 0);
		if (f1)glRotatef(Rotation.x, 1, 0, 0);
		if (f3)glRotatef(Rotation.z, 0, 0, 1);
	}
	void Rotation_Close(int f1, int f2, int f3)
	{
		if (f3)glRotatef(-Rotation.z, 0, 0, 1);
		if (f1)glRotatef(-Rotation.x, 1, 0, 0);
		if (f2)glRotatef(-Rotation.y, 0, 1, 0);
	}

	void RotateUntil_Y(D_Vertex FROM, D_Vertex TO, int add)
	{
		if (TO.x > FROM.x)
		{
			if (TO.z > FROM.z)
				Rotation.y = (int)(atan(abs((TO.x) - (FROM.x)) / abs((TO.z) - (FROM.z))) * 180.0 / PI) + add;
			else
				Rotation.y = 180 - (int)(atan(abs((TO.x) - (FROM.x)) / abs((FROM.z) - (TO.z))) * 180.0 / PI) + add;
			
		}
		else
		{
			if (TO.z > FROM.z)
				Rotation.y = 360 - (int)(atan(abs((FROM.x) - (TO.x)) / abs((TO.z) - (FROM.z))) * 180.0 / PI) + add;
			else
				Rotation.y = 180 + (int)(atan(abs((FROM.x) - (TO.x)) / abs((FROM.z) - (TO.z))) * 180.0 / PI) + add;
		}
	}

	void RotateUntil_X_Half(D_Vertex FROM, D_Vertex TO, int add)
	{
		float Under;
		if (abs((TO.z) - (FROM.z)) > abs((TO.x) - (FROM.x)))
			Under = abs((TO.z) - (FROM.z));
		else
			Under = abs((TO.x) - (FROM.x));
		if (FROM.z < TO.z)
		{
			if (TO.y > FROM.y)
				Rotation.x = -(int)(atan(abs((TO.y) - (FROM.y)) / Under) * 180.0 / PI) + add;
			else
				Rotation.x = (int)(atan(abs((TO.y) - (FROM.y)) / Under) * 180.0 / PI) + add;
		}
		else
		{
			if (TO.y > FROM.y)
				Rotation.x = -(int)(atan(abs((TO.y) - (FROM.y)) / Under) * 180.0 / PI) + add;
			else
				Rotation.x = (int)(atan(abs((TO.y) - (FROM.y)) / Under) * 180.0 / PI) + add;
		}
	}
};
class Box : public LocationAble, public RotationAble
{
public:
	int Nets_Count;
	float PlusX, PlusZ;
	int Moving_Location = 0;
	int Moving_Rotation = 0;
	int Moving_Size = 0;
	int Moving_Color = 0;
	bool ReqMove;
	D_Vertex LocationFrom, LocationTo, LocationSpeed;
	D_Vertex RotationFrom, RotationTo, RotationSpeed;
	D_Vertex Size, SizeFrom, SizeTo, SizeSpeed;
	D_Vertex Color, ColorFrom, ColorTo, ColorSpeed;
	Box()
	{
		Nets_Count = 0;
		PlusX = PlusZ = 0;
		Location.Set_(0, 0, 0);
		Rotation.Set_(0, 0, 0);
		Size.Set_(1, 1, 1);
		Color.Set_(1, 1, 1);
	}
	Box(const Box& other)
	{
		Location = other.Location;
		Rotation = other.Rotation;
		Size = other.Size;
		Nets_Count = other.Nets_Count;
		PlusX = other.PlusX;
		PlusZ = other.PlusZ;
		Color.Set_(1, 1, 1);
	}
	void Copy(Box* other)
	{
		Location = other->Location;
		Rotation = other->Rotation;
		Size = other->Size;
		Color = other->Color;
		PlusX = other->PlusX;
		PlusZ = other->PlusZ;
		Nets_Count = other->Nets_Count;
	}
	Box& operator =(const Box& other)
	{
		Location = other.Location;
		Rotation = other.Rotation;
		Size = other.Size;
		Color = other.Color;
		Nets_Count = other.Nets_Count;
		PlusX = other.PlusX;
		PlusZ = other.PlusZ;
		return *this;
	}
	void Draw()
	{
		Go_Location();
		Rotation_Open(1, 1, 1);
		Color.Color_On();
		Draw_Box(this);
		Rotation_Close(1, 1, 1);
		Back_Location();
	}
	void Draw_Box(Box* B)
	{
		float cx, cy, cz;
		cx = B->Size.x / 2;
		cy = B->Size.y / 2;
		cz = B->Size.z / 2;

		glBegin(GL_QUADS);
		// Front
		glNormal3f(0, 0, 1);
		glVertex3f(-cx, -cy, cz);
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f(cx, -cy, cz);

		// Back
		glNormal3f(0, 0, -1);
		glVertex3f(-cx, -cy, -cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));

		// Left side
		glNormal3f(-1, 0, 0);
		glVertex3f(-cx, -cy, cz);
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-cx, -cy, -cz);

		// Right side
		glNormal3f(1, 0, 0);
		glVertex3f(cx, -cy, cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));

		// Up side
		glNormal3f(0, 0, 1);
		glVertex3f((cx + B->PlusX), cy, (cz + B->PlusZ));
		glVertex3f((cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, -(cz + B->PlusZ));
		glVertex3f(-(cx + B->PlusX), cy, (cz + B->PlusZ));

		// down side
		glNormal3f(0, 0, 1);
		glVertex3f(cx, -cy, cz);
		glVertex3f(cx, -cy, -cz);
		glVertex3f(-cx, -cy, -cz);
		glVertex3f(-cx, -cy, cz);
		glEnd();

		glColor3f(0, 0, 0);
		if (B->Nets_Count > 0)
		{
			float difz = ((cz + B->PlusZ) * 2) / B->Nets_Count;
			float difx = ((cx + B->PlusX) * 2) / B->Nets_Count;
			float dify = (cy * 2) / B->Nets_Count;
			float difzc = (cz * 2) / B->Nets_Count;
			float difxc = (cx * 2) / B->Nets_Count;
			for (int i = 0; i <= B->Nets_Count; i++)
			{
				glLineWidth(2);
				glBegin(GL_LINES);
				glVertex3f((cx + B->PlusX), cy + 0.005, (cz + B->PlusZ) - (difz * i));//Up Side
				glVertex3f(-(cx + B->PlusX), cy + 0.005, (cz + B->PlusZ) - (difz * i));
				glVertex3f((cx + B->PlusX) - (difx * i), cy + 0.005, (cz + B->PlusZ));
				glVertex3f((cx + B->PlusX) - (difx * i), cy + 0.005, -(cz + B->PlusZ));

				glVertex3f((cx), -(cy + 0.005), (cz)-(difzc * i));//Down Side
				glVertex3f(-(cx), -(cy + 0.005), (cz)-(difzc * i));
				glVertex3f((cx)-(difxc * i), -(cy + 0.005), (cz));
				glVertex3f((cx)-(difxc * i), -(cy + 0.005), -(cz));

				glVertex3f((cx + B->PlusX) - (difx * i), cy + 0.005, (cz + B->PlusZ) + 0.005);//Front Side
				glVertex3f((cx)-(difxc * i), -(cy + 0.005), cz + 0.005);

				glVertex3f((cx + B->PlusX) - (difx * i), cy + 0.005, -((cz + B->PlusZ) + 0.005));//Back Side
				glVertex3f((cx)-(difxc * i), -(cy + 0.005), -(cz + 0.005));

				glVertex3f(-(cx + B->PlusX + 0.005), cy + 0.005, (cz + B->PlusZ) - (difz * i));//Left Side
				glVertex3f(-(cx + 0.005), -(cy + 0.005), (cz)-(difzc * i));

				glVertex3f(cx + B->PlusX + 0.005, cy + 0.005, (cz + B->PlusZ) - (difz * i));//Right Side
				glVertex3f(cx + 0.005, -(cy + 0.005), (cz)-(difzc * i));

				glEnd();

			}
		}
	}
	void move()
	{
		if (Moving_Location)Location.Move(&LocationFrom, &LocationTo, &LocationSpeed, ReqMove);
		if (Moving_Rotation)Rotation.Move(&RotationFrom, &RotationTo, &RotationSpeed, ReqMove);
		if (Moving_Size)Size.Move(&SizeFrom, &SizeTo, &SizeSpeed, ReqMove);
		if (Moving_Color)Color.Move(&ColorFrom, &ColorTo, &ColorSpeed, ReqMove);
	}
};